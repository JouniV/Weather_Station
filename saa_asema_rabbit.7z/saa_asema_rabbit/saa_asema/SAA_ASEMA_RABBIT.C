/*****************************************************************************
 * OHJELMA:		saa_asema_rabbit.c
 *
 * Kuvaus:	Ohjelma alkaa mittaamaan lampotilaa sen jalkeen, kun
 *			asiakasohjelma on muodostanut TCP socket yhteyden
 *			socket porttiin, jota ohjelma kuuntelee. Lampotilaa
 *			mittaava anturi on kiinnitetty kortin reunassa oleviin
 *			ruuviliittimiin.
 *
 *			Lampotilaa mittaava anturi on kytketty Rabbit kortin linjoihin
 *			PG7 ja PE0. Toisin sanoen kaytoss� on portti G / linja 7 ja
 *			portti E / linja 0.
 *
 *			Linjaa PG7 kaytetaan IC1 input capture toimintoon ja linjaa PE0
 *			ulkoiseen INT0 keskeytykseen. Keskeytyslinja INT0 tulee vakiona
 *			kortin reunassa olevaan ruuviliittimeen, joten anturin ulostulo
 *			voidaan kytkea siihen.
 *
 *			Linja PG7 on vedetty lattakaapeli johdolla erikseen INT0 liittimeen,
 *			koska linja ei tule vakiona ruuviliittimelle. Myos anturin sahkonsyotto
 *			on otettu ruuviliittimista.
 *
 *			Ohjelma vilkuttaa kortilla olevaa ns. kayttajan ledia ohjelmistoon
 *			maaritetyn kayntinopeuden tahdissa, joten sita voidaan kayttaa
 *			ohjelmiston valvontaan paikallisesti. Jos kayntinopeus on 5 sekuntia,
 *			niin ledi syttyy ja sammuu 5 sekunnin valein.
 *
 *			Ohjelmisto on tehty Rabbit kortin omalla C ristikaantajalla. Kortin
 *			mukana tulee IDE (Integrated Development Environment) kehitysymparisto,
 *			jolla ohjelmisto on toteutettu. Socket toimintojen toteutuksessa on kaytetty
 *			kaantajan TCP/IP kirjastoa. Ohjelmisto kehitetaan Windows tyoasema
 *			ymparistossa ja kaannoksen jalkeen se siirretaan Rabbit kortille
 *			sarjaporttiin kytketyn kaapelin valityksella.
 *
 *
 *			Modulin toiminta on seuraavanlainen:
 *
 *			- Asiakasohjelmisto muodostaa Rabbit ohjelmaan ensin TCP socket yhteyden
 *				- Ohjelma kuuntelee TCP socket porttia yhteydenottoon asti
 *
 *			- Sallitaan ulkoinen INT0 keskeytys
 *				- Keskeytys pulssin nousevalla reunalla
 *
 *			- Sallitaan IC1 input capture laskuri toiminto
 *				- Laskurin kaynnistys pulssin laskevalla reunalla
 *				- Laskurin pysaytys pulssin nousevalla reunalla
 *
 *			- Mitataan pulssin alhaallaoloaika naytteita ja otetaan ne talteen
 *			  keskeytyspalvelu funktiossa aina, kun ulkoinen INT0 keskeytys aktivoituu
 *			- Mitattavien naytteiden maara on vakioitu ohjelmaan ja sita voidaan muuttaa
 *
 *			- Kun naytteet on mitattu, niin estetaan ulkoinen INT0 keskeytys
 *			- Estetaan IC1 input capture laskuri toiminto
 *
 *			- Sallitaan ulkoinen INT0 keskeytys
 *				- Keskeytys pulssin laskevalla reunalla
 *
 *			- Sallitaan IC1 input capture laskuri toiminto
 *				- Laskurin kaynnistys pulssin nousevalla reunalla
 *				- Laskurin pysaytys pulssin laskevalla reunalla
 *
 *			- Mitataan pulssin ylhaallaoloaika naytteita ja otetaan ne talteen
 *			  keskeytyspalvelu funktiossa aina, kun ulkoinen INT0 keskeytys aktivoituu
 *				- Mitattavien naytteiden maara on vakioitu ohjelmaan ja sita voidaan muuttaa
 *
 *			- Kun naytteet on mitattu, niin estet��n ulkoinen INT0 keskeytys
 *			- Estetaan IC1 input capture laskuri toiminto
 *
 *			- Lasketaan lampotilanaytteiden keskiarvo
 *
 *			- Valitetaan keskiarvo lampotila asiakasohjelmalle TCP socket yhteyden kautta
 *
 *			- Samaa toistetaan, kunnes asiakasohjelma sulkee TCP socket yhteyden
 *			  tai se sulkeutuu esim. verkkokatkoksen takia
 *
 *			- Rabbit ohjelma palaa TCP socketin kuuntelutilaan, jos sockettiin kirjoitus
 *			  epaonnistuu tai lampotila -anturilta ei saada pulsseja. Sockettiin kirjoitus
 *			  voi epaonnistua, jos asiakasohjelma on sulkenut socket yhteyden tai verkkoyhteys
 *			  menee poikki. Pulssien saaminen lampotila -anturilta voi loppua, jos anturi
 *			  on kiinnitetty huonosti kortin liittimiin. Lampotilatietojen mittaus ja
 *			  valitys jatkuu taas normaalisti, kun asiakasohjelma muodostaa Rabbit ohjelmistoon
 *			  uuden socket yhteyden.
 *
 *			- Ohjelman paallaoloa voidaan valvoa etayhteydella verkon yli annettavalla ping komennolla,
 *			  johon ohjelma vastaa aina paallaollessaan. Valvonta voidaan ajastaa esim. UNIX- tai
 *			  Linux kayttojarjestelmien croniin. Virhetilanteista voidaan lahettaa ilmoitus sahkopostina
 *			  SMTP palvelimen valityksella tai tekstiviestina Content Gateway palvelimen valityksella.
 *			  Virheviestien lahetyksen edellytyksena on, ett� loppuasiakkaalla on olemassa toimivat yhteydet
 *			  SMTP- ja/tai Content Gateway palvelimiin.
 *
 *				PARAMETRIT:
 *					- Ei input parametreja
 *
 *				PALUUARVOT:
 *					- Ei paluuarvoa, koska ohjelmaa ajetaan Rabbit -kortilla
 *
 *				KESKEYTYKSEN HALLINTA:
 *					- Keskeytystilanteessa lampotilatietojen valitys asiakasohjelmalle lopetetaan
 *
 *				UUDELLEEN KAYNNISTYS:
 *					- Korttiin kytketaan virrat ja sen jalkeen ohjelma siirretaan kortille,
 *					  jonka jalkeen ohjelma kaynnistyy
 *
 *
 *				14.01.2009 Jouni Virtanen
 *
 *
 **************************************************************************/

#class auto

//
// Katso Rabbitin LIB\TCPIP\TCP_CONFIG.LIB tiedostosta TCPCONFIG maarittelyn eri arvot.
// DHCP on talla asetuksella kaytossa.
//
// Staattinen DHCP IP -osoite saadaan TeleWell modemilta, kun Rabbit kortin
// MAC -osoite on maaritelty ensin modemin DHCP Server asetuksiin.
//
#define 	TCPCONFIG 3

//
// This macro causes the MAC address to be used as a unique client
// identifier.
#ifndef DHCP_CLIENT_ID_MAC
	#define DHCP_CLIENT_ID_MAC
#endif


#memmap	xmem
#use	dcrtcp.lib
#use	rcm33xx.lib


//
// Kuunneltavan socket portin numero
//
#define	RABBIT_SOCKET_PORT			80

//
// 1 = kaytetaan nopeaa keskeytysta I&D tilassa
//
#define	FAST_INTERRUPT				0

//
// Mitattavien lampotilanytteiden maara
//
#define	NAYTTEIDEN_LUKUMAARA		20

//
// Maksimi aika millisekunteina, jonka lampotilanaytteiden mittaus saa kestaa
//
#define	NAYTTEIDEN_ODOTUSAIKA		1000

//
// Ohjelman kayntinopeus millisekunteina
//
#define	OHJELMAN_KAYNTI_NOPEUS_MS	5000

//
// Arvo ilmaisee, etta lampotilan mittauksessa on tapahtunut virhe
//
#define	LAMPOTILAN_MITTAUS_VIRHE	-1000

//
// Asiakaohjelman lahettama OK kuittaus
//
#define	ASIAKAS_OHJELMAN_OK_KUITTAUS	"OK"

//
// Asiakasohjelmalle lahetettava virheilmoitus, jos lampotila -anturilta ei saada pulsseja
//
#define	ANTURI_EI_TOIMI					"RABBIT KORTIN ANTURI EI TOIMI"

//
// Funktioiden esittelyt
//
void keskeytysPalvelu_1();
void keskeytysPalvelu_2();

//
// Lampotilanayte -taulukoiden indeksi
//
int i;

//
// Lampotilanayte -taulukko pulssin alhaallaoloajalle
//
unsigned char cAlhaallaOloaikaMSB[NAYTTEIDEN_LUKUMAARA];
unsigned char cAlhaallaOloaikaLSB[NAYTTEIDEN_LUKUMAARA];

//
// Lampotilanayte -taulukko pulssin ylhaallaoloajalle
//
unsigned char cYlhaallaOloaikaMSB[NAYTTEIDEN_LUKUMAARA];
unsigned char cYlhaallaOloaikaLSB[NAYTTEIDEN_LUKUMAARA];



/***************************************************************************\
* FUNKTIO
*		asetaKeskeytysPalvelu_1 ();
*
* INPUT
*	Ei input parametreja.
*
* OUTPUT
*	Ei paluuarvoa.
*
* KUVAUS
*	Asettaa kaytettavan keskeytyspalvelu funktion osoitteen.
*
\***************************************************************************/
void asetaKeskeytysPalvelu_1()
{

	// Asetetaan keskeytyspalvelu funktioiden osoitteet
#if __SEPARATE_INST_DATA__ && FAST_INTERRUPT
	interrupt_vector ext0_intvec keskeytysPalvelu_1;
#else
	SetVectExtern3000(0, keskeytysPalvelu_1);
#endif
}


/***************************************************************************\
* FUNKTIO
*		asetaKeskeytysPalvelu_2 ();
*
* INPUT
*	Ei input parametreja.
*
* OUTPUT
*	Ei paluuarvoa.
*
* KUVAUS
*	Asettaa kaytettavan keskeytyspalvelu funktion osoitteen.
*
\***************************************************************************/
void asetaKeskeytysPalvelu_2()
{

	// Asetetaan keskeytyspalvelu funktioiden osoitteet
#if __SEPARATE_INST_DATA__ && FAST_INTERRUPT
	interrupt_vector ext0_intvec keskeytysPalvelu_2;
#else
	SetVectExtern3000(0, keskeytysPalvelu_2);
#endif
}


/***************************************************************************\
* FUNKTIO
*		alustaRabbitkortti
*			(
*				int sI0CR,
*				int sICS1R,
*				int sICT1R,
*				void (*fpAsetaKeskeytyspalveluFunktio) ()
*			);
*
* INPUT
*	sI0CR							- I0CR rekisteriin kirjoitettava arvo
*	sICS1R							- ICS1R rekisteriin kirjoitettava arvo
*	sICT1R							- ICT1R rekisteriin kirjoitettava arvo
*	fpAsetaKeskeytyspalveluFunktio	- Funktio, joka asettaa keskeytyspalvelun
*
* OUTPUT
*	Ei paluuarvoa
*
* KUVAUS
*	Alustaa Rabbit kortin rekisterit lampotilan mittausta varten.
*	
*
\***************************************************************************/
void alustaRabbitkortti
(
	int sI0CR,
	int sICS1R,
	int sICT1R,
	void (*fpAsetaKeskeytyspalveluFunktio) ()
)
{

	// Estetaan "IC1 input capture" laskuri toiminto
	WrPortI(ICT1R, NULL, 0x00);

	// Kaytetaan nopeampaa kellotusta Timer A:lle, jotta saadaan isompia "input capture" laskurin arvoja
	BitWrPortI(TACSR, &TACSRShadow, 1, 0);
	BitWrPortI(TAPR, &TAPRShadow, 0, 0);

	// Portin E linjat inputeiksi
	WrPortI(PEDDR, &PEDDRShadow, 0x00);

	// Asetetaan kaytettavan keskeytyspalvelu funktion osoite
	(*fpAsetaKeskeytyspalveluFunktio) ();

	// Sallitaan ulkoinen INT0 keskeytys
	WrPortI(I0CR, &I0CRShadow, sI0CR);

	// Maaritetaan kaytettava "IC1 input capture" linja
	WrPortI(ICS1R, NULL, sICS1R);

	// Nollataan "IC1 input capture" laskuri
	WrPortI(ICCSR, NULL, 0x0C);

	// Ei kayteta "IC1 input capture" toiminnon omaa keskeytysta
	WrPortI(ICCR, NULL, 0x00);

	// Sallitaan "IC1 input capture" laskuri toiminto
	WrPortI(ICT1R, NULL, sICT1R);
}


/***************************************************************************\
* FUNKTIO
*		palautaTimer_A_Kellotus ();
*
* INPUT
*	Ei input parametreja.
*
* OUTPUT
*	Ei paluuarvoa.
*
* KUVAUS
*	Palauttaa Timer A:lle normaali kellotuksen, jotta kortin sarjaliikenne
*	palautuu toimivaksi.
*
\***************************************************************************/
void palautaTimer_A_Kellotus()
{

	// Palautetaan Timer A:n kellotus
	BitWrPortI(TAPR, &TAPRShadow, 1, 0);
}


/***************************************************************************\
* FUNKTIO
*		odotaNaytteidenMittausta (float *fLampoTila);
*
* INPUT
*	fLampoTila - output parametrin osoite
*
* OUTPUT
*	fLampoTila - 0 = mittaus onnistui / LAMPOTILAN_MITTAUS_VIRHE = virhe
*
* KUVAUS
*	Odottaa, etta lampotilanaytteet saadaan mitattua. Mittaus saa kestaa
*	enintaan NAYTTEIDEN_ODOTUSAIKA vakion verran.
*
*	Palauttaa vakion LAMPOTILAN_MITTAUS_VIRHE jos mittaus kestaa kauemmin.
*
\***************************************************************************/
float odotaNaytteidenMittausta(float *fLampoTila)
{
	unsigned long lMillisekunnit;

	i = 0;
	*fLampoTila = 0;
	lMillisekunnit = MS_TIMER;
	while (i < NAYTTEIDEN_LUKUMAARA)
	{
		// Jos mittaus kestaa liian kauan, niin lampotila -anturilta ei ilmeisesti tule pulsseja
		if (MS_TIMER - lMillisekunnit > NAYTTEIDEN_ODOTUSAIKA)
		{
			*fLampoTila = LAMPOTILAN_MITTAUS_VIRHE;
			break;
		}
	}

	// Palautetaan Timer A:lle normaali kellotus
	palautaTimer_A_Kellotus();

	return *fLampoTila;
}


/***************************************************************************\
* FUNKTIO
*		mittaaLampoTila ();
*
* INPUT
*	Ei input parametreja.
*
* OUTPUT
*	Palauttaa lampotila -anturilla mitattujen lampotilanaytteiden
*	keskiarvon.
*
* KUVAUS
*	Mittaa NAYTTEIDEN_LUKUMAARA vakion verran lampotilanaytteita.
*	Laskee naytteiden keskiarvon ja palauttaa lasketun lampotilan keskiarvon.
*
\***************************************************************************/
float mittaaLampoTila()
{
	float	fAlhaalla, fYlhaalla;
	int		sNayte;
	float	fLampoTila;
	int		j;


	//
	// Sallitaan ulkoinen INT0 keskeytys E portin linjassa 0
	//
	// Keskeytys pulssin nousevalla reunalla, priorieetti 1
	//
	// Kaytetaan G portin linjaa 7 "IC1 input capture" laskuri toimintoon,
	// lampotilanaytteet mitataan siis talla linjalla.
	//
	// Sallitaan "IC1 input capture" laskuri toiminto
	//
	// Laskuri askeltaa start ehdosta -> stop ehtoon asti
	//
	// Start ehto on laskeva reuna ja stop ehto on nouseva reuna
	//
	// "IC1 input capture" toiminto tallentaa laskurin arvon rekisteriin, kun stop ehto saavutetaan.
	// Rekisterin arvo luetaan keskeytyspalveu funktiossa.
	//
	alustaRabbitkortti(0x09, 0xFF, 0x59, asetaKeskeytysPalvelu_1);

	// Odotetaan pulssin alhaallaoloaika lampotilanaytteiden mittausta
	odotaNaytteidenMittausta(&fLampoTila);

	// Jos lampotilanaytteiden mittaus onnistui
	if (fLampoTila != LAMPOTILAN_MITTAUS_VIRHE)
	{
		//
		// Sallitaan ulkoinen INT0 keskeytys E portin linjassa 0
		//
		// Keskeytys pulssin laskevalla reunalla, priorieetti 1
		//
		// Kaytetaan G portin linjaa 7 "IC1 input capture" laskuri toimintoon,
		// lampotilanaytteet mitataan siis talla linjalla
		//
		// Sallitaan "IC1 input capture" laskuri toiminto
		//
		// Laskuri askeltaa start ehdosta -> stop ehtoon asti
		//
		// Start ehto on nouseva reuna ja stop ehto on laskeva reuna
		//
		// "IC1 input capture" toiminto tallentaa laskurin arvon rekisteriin, kun stop ehto saavutetaan.
		// Rekisterin arvo luetaan keskeytyspalveu funktiossa.
		//
		alustaRabbitkortti(0x05, 0xFF, 0x56, asetaKeskeytysPalvelu_2);

		// Odotetaan pulssin ylhaallaoloaika lampotilanaytteiden mittausta
		odotaNaytteidenMittausta(&fLampoTila);
	}

	// Jos lampotilanaytteiden mittaus onnistui
	if (fLampoTila != LAMPOTILAN_MITTAUS_VIRHE)
	{
		// Lasketaan lampotilanaytteiden keskiarvo, ensimmainen nayte hylataan
		fAlhaalla = 0;
		fYlhaalla = 0;
		for (j = 0; j < NAYTTEIDEN_LUKUMAARA; j++)
		{
			if (j > 0)
			{
				sNayte = cAlhaallaOloaikaMSB[j] << 8;
				sNayte |= cAlhaallaOloaikaLSB[j];
				fAlhaalla += sNayte;
				//printf("Alhaalla: %X %X / %X\n", cAlhaallaOloaikaMSB[j], cAlhaallaOloaikaLSB[j], sNayte);

				sNayte = cYlhaallaOloaikaMSB[j] << 8;
				sNayte |= cYlhaallaOloaikaLSB[j];
				fYlhaalla += sNayte;
				//printf("Ylhaalla: %X %X / %X\n", cYlhaallaOloaikaMSB[j], cYlhaallaOloaikaLSB[j], sNayte);
			}
		}
		fAlhaalla /= (NAYTTEIDEN_LUKUMAARA - 1);
		fYlhaalla /= (NAYTTEIDEN_LUKUMAARA - 1);

		// Muutetaan ylhaalla- ja alhaallaoloaika laskurien arvot lampotilaksi
		fLampoTila = ( ( fYlhaalla / (fYlhaalla + fAlhaalla) ) - 0.32 ) / 0.0047;
	}

	return fLampoTila;
}


/***************************************************************************\
* FUNKTIO
*		kayntinopeusViive(unsigned long *lMillisekunnit, char *cLedinTila);
*
* INPUT
*	lMillisekunnit	- MS_TIMER muuttujan arvo, joka sisaltaa nykyisen ajan
*					  millisekunteina
*	cLedinTila		- Kortilla olevan kayttajan ledin tila
*						1 - ledi on paalla
*						0 - ledi ei ole paalla
*
* OUTPUT
*	lMillisekunnit	- MS_TIMER muuttujan uusi arvo milisekunteina,
*					  jos kayntinopeus viive saavutettiin
*	cLedinTila		- Kortilla olevan kayttajan ledin uusi tila,
*					  jos kayntinopeus viive saavutettiin
*						1 - ledi on paalla
*						0 - ledi ei ole paalla
*
*	Palauttaa 1, jos kayntinopeus viive savutettiin muuten 0.
*
* KUVAUS
*	Vaihtaa kortilla olevan kayttajan ledin tilaa aina, kun kayntinopeus
*	viive saavutetaan. Kutsuu jokaisella suorituskerralla tcp_tick funktiota
*	jotta TCP/IP liikennointi toimisi ongelmitta ja korttia voitaisiin pingata
*	verkon yli.
*
\***************************************************************************/
int kayntinopeusViive(unsigned long *lMillisekunnit, char *cLedinTila)
{
	char cOK;

	// Jos kayntinopeusViive on saavutettu, niin vaihdetaan kayttajan ledin
	// tilaa ja palautetaan 1
	cOK = 0;
	if (MS_TIMER - *lMillisekunnit >= OHJELMAN_KAYNTI_NOPEUS_MS)
	{
		*lMillisekunnit = MS_TIMER;
		*cLedinTila = !*cLedinTila;
		ledOut(0, *cLedinTila);
		cOK = 1;
	}

	tcp_tick(NULL);

	return cOK;
}


/***************************************************************************\
* FUNKTIO
*		main();
*
* INPUT
*	Ei input parametreja.
*
* OUTPUT
*	Ei paluuarvoa.
*
* KUVAUS
*	Ohjelman main funktio.
*
\***************************************************************************/

void main()
{
	float			fLampoTila;
	char			cSocketYhteysMuodostettu;
	char			szSocketpuskuri[100];		// Currently (DC 7.30), printf() has max 127 bytes it can output.
	unsigned long	lMillisekunnit;
	char 			cLedinTila;
	tcp_Socket 		socket;
	int				sPituus, j;


	// Rabbit kortin alustus, jotta kayttajan ledin vilkutus onnistuisi
	brdInit();
	cLedinTila = 0;

	// Socket yhteyden alustus
	sock_init();
	cSocketYhteysMuodostettu = 0;

	// Valitetaan asiakasohjelmalle lampotilatietoja
	while (1)
	{
		fLampoTila = 0;

		// Jos asiakasohjelma ei ole muodostanut socket yhteytta
		if (!cSocketYhteysMuodostettu)
		{
			// Odotetaan asiakasohjelman socket yhteyden muodostusta
			// silmukassa ja vaihdetaan kayttajan ledin tilaa aina, kun
			// kayntinopeus on saavutettu
			tcp_listen(&socket, RABBIT_SOCKET_PORT, 0, 0, NULL, 0);
			printf("Odotetaan asiakas ohjelman socket yhteydenottoa...\n");

			lMillisekunnit = MS_TIMER;
			while(!sock_established(&socket))
			{
				costate
				{
					kayntinopeusViive(&lMillisekunnit, &cLedinTila);

					// Annetaan muille prosesseille suoritusaikaa
					yield;
				}
			}

			// Asiakasohjelma muodosti socket yhteyden
			printf("Socket yhteys muodostettu...\n");
			cSocketYhteysMuodostettu = 1;
		}


		// Mitataan lampotila
		fLampoTila = mittaaLampoTila();

		// Lahetetaan asiakas ohjelmalle virheilmoitus, jos lampotilan mittauksessa tapahtui virhe
		if (fLampoTila == LAMPOTILAN_MITTAUS_VIRHE)
		{
			strcpy(szSocketpuskuri, ANTURI_EI_TOIMI);
			printf("%s\n", ANTURI_EI_TOIMI);
		}
		// Lahetetaan lampotila
		else
		{
			printf("%.1f\n", fLampoTila);
			sprintf(szSocketpuskuri, "%.1f", fLampoTila);
		}

		// Lahetetaan lampotila tai ilmoitus asiakasohjelmalle socket yhteyden kautta
		if (sock_fastwrite(&socket, szSocketpuskuri, sizeof(szSocketpuskuri)) < 0)
		{
			// Suljetaan socket yhteys, jos lampotilan valitys epaonnistui
			printf("Socket kirjoitus epaonnistui\n");
			sock_close(&socket);
			cSocketYhteysMuodostettu = 0;
		}
		else
		{
			printf("Tiedot lahetetty sockettiin\n");
		}

		// Odotetaan kayntinopeus viiveen verran asiakas ohjelman OK kuittausta
		if (cSocketYhteysMuodostettu)
		{
			cSocketYhteysMuodostettu = 0;
			strcpy(szSocketpuskuri, "");
			lMillisekunnit = MS_TIMER;
			while (!kayntinopeusViive(&lMillisekunnit, &cLedinTila))
			{
				costate
				{
					// Jos asiakas ohjelmalta ei ole viela saatu dataa
					if (!strlen(szSocketpuskuri))
					{
						// Luetaan sockettia
						if ((sPituus = sock_fastread(&socket, szSocketpuskuri, sizeof(szSocketpuskuri) - 1)) < 0)
						{
							printf("Socket luku epaonnistui\n");
							break;
						}
						// Jos asiakas ohjelmalta saatiin dataa
						else
						{
							// Laitetaan datan peraan NULL
							szSocketpuskuri[sPituus] = 0;

							// Oliko OK kuittaus
							if (!strcmp(szSocketpuskuri, ASIAKAS_OHJELMAN_OK_KUITTAUS))
							{
								printf("Asiakas ohjelmalta saatiin OK kuittaus\n");
								cSocketYhteysMuodostettu = 1;
							}
						}
					}

					// Annetaan muille prosesseille suoritusaikaa
					yield;
				}
			}
		}

		// Jos asiakas ohjelmalta ei saatu OK kuittausta
		if (!cSocketYhteysMuodostettu)
		{
			// Suljetaan socket yhteys
			printf("Asiakas ohjelmalta ei saatu OK kuittausta\n");
			sock_close(&socket);
		}
	}

	WrPortI(I0CR, &I0CRShadow, 0x00);		// Estetaan ulkoinen INT0 keskeytys

}


/****** Keskeytyspalvelu funktiot  ******/


/***************************************************************************\
* FUNKTIO
*		keskeytysPalvelu_1 ();
*
* INPUT
*	Ei input parametreja.
*
* OUTPUT
*	Ei paluuarvoa.
*
* KUVAUS
*	Keskeytyspalvelu funktio alhaallaoloaika naytteiden tallennukseen.
*
\***************************************************************************/
nodebug root interrupt void keskeytysPalvelu_1()
{

	//while (!(RdPortI(ICCSR) & 0x10));

	// Otetaan 16 bittisen "input capture" laskurin vahiten merkitseva tavu talteen (8 alinta bittia)
	cAlhaallaOloaikaLSB[i] = RdPortI(ICL1R);

	// Otetaan 16 bittisen "input capture" laskurin eniten merkitseva tavu talteen (8 ylinta bittia)
	cAlhaallaOloaikaMSB[i] = RdPortI(ICM1R);

	// Kasvatetaan taulukon indexia
	// Jos kaikki naytteet saatiin otettua, niin estetaan ulkoinen keskeytys, muuten nollataan "input capture" laskuri
	i++;
	if (i == NAYTTEIDEN_LUKUMAARA)
	{
		WrPortI(I0CR, &I0CRShadow, 0x00);	// Estetaan ulkoinen INT0 keskeytys
		// Estetaan "IC1 input capture" laskuri toiminto
		WrPortI(ICT1R, NULL, 0x00);
	}
	else
		WrPortI(ICCSR, NULL, 0x04);			// Nollataan "IC1 input capture" laskuri
}


/***************************************************************************\
* FUNKTIO
*		keskeytysPalvelu_2 ();
*
* INPUT
*	Ei input parametreja.
*
* OUTPUT
*	Ei paluuarvoa.
*
* KUVAUS
*	Keskeytyspalvelu funktio ylhaallaoloaika naytteiden tallennukseen.
*
\***************************************************************************/
nodebug root interrupt void keskeytysPalvelu_2()
{

	//while (!(RdPortI(ICCSR) & 0x10));

	// Otetaan 16 bittisen "input capture" laskurin vahiten merkitseva tavu talteen (8 alinta bittia)
	cYlhaallaOloaikaLSB[i] = RdPortI(ICL1R);

	// Otetaan 16 bittisen "input capture" laskurin eniten merkitseva tavu talteen (8 ylinta bittia)
	cYlhaallaOloaikaMSB[i] = RdPortI(ICM1R);

	// Kasvatetaan taulukon indexia
	// Jos kaikki naytteet saatiin otettua, niin estetaan ulkoinen keskeytys, muuten nollataan "input capture" laskuri
	i++;
	if (i == NAYTTEIDEN_LUKUMAARA)
	{
		WrPortI(I0CR, &I0CRShadow, 0x00);	// Estetaan ulkoinen INT0 keskeytys
		// Estetaan "IC1 input capture" laskuri toiminto
		WrPortI(ICT1R, NULL, 0x00);
	}
	else
		WrPortI(ICCSR, NULL, 0x04);			// Nollataan "IC1 input capture" laskuri
}

