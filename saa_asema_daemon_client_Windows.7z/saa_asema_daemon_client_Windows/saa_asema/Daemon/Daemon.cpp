/*****************************************************************************
 * OHJELMA:		daemon.c
 *
 * Kuvaus:		Ohjelma muodostaa TCP/IP socket yhteyden Rabbit -kortin
 *				ohjelmaan, joka kuuntelee socket porttia. Rabbit ohjelmisto
 *				mittaa lampotilaa ja valittaa lampotilatietoja socket yhteyden
 *				valityksella tietyin valiajoin Daemon ohjelmalle.
 *
 *				Daemon ohjelma keraa lampotilatietoja muistiin ja tallentaa ne
 *				CSV -muodossa levylle myohempaa tarkastelua varten.
 *
 *				lampotilatietoja kerataan muistiin ensin DAEMON_DATA_PUSKURI_KOKO
 *				vakion verran ja vasta sen jalkeen tietoja yritetaan tallentaa levylle.
 *				Jos tietojen tallennus epaonnistuu, niin lampotilatietoja kerataan
 *				muistiin enintaan DAEMON_DATA_PUSKURI_MAX_KOKO vakion verran
 *				ja taman jalkeen mahdollinen epaonnistunut tallennus tulkitaan
 *				virheena ja ohjelman suoritus keskeytetaan.
 *
 *				Lampotilatietojen tallennus yritys tiedostoon voi epaonnistua, jos
 *				tiedosto on avattu esim. Excel ohjelmaan Windows ymparistossa.
 *				Kun tiedoston lukitus poistuu esim. Excel suljetaan, niin kaikki
 *				siihen mennessa muistiin keratyt tiedot tallennetaan levylle
 *				seuraavan tallennus yrityksen yhteydessa.
 *
 *				Koska ohjelma jaa keraamaan lampotilatietoja paattymattomaan
 *				silmukkaan, niin sen suoritus taytyy keskeyttaa, kun tietojen
 *				kerays halutaan lopettaa. Windows ymparistossa ohjelmaa suorittava
 *				DOS -ikkuna suljetaan ja UNIX/Linux ymparistossa tausta -ajona
 *				suoritettava ohjelma tapetaan kayttojarjestelman kill komennolla.
 *
 *				Myohemmassa vaiheessa ohjelmaan voidaan toteuttaa signal handler 
 *				toiminto, jolloin ohjelma voidaan ajaa hallitusti alas
 *				UNIX/Linux ymparistoissa kayttojarjestelman kill komennolla ja
 *				esim. kayttajan SIGUSR1 signaalilla.
 *
 *				Ohjelman paallaolon valvonta voidaan ajastaa esim. UNIX- tai
 *				Linux kayttojarjestelmien croniin. Virhetilanteista voidaan lahettaa ilmoitus sahkopostina
 *				SMTP palvelimen valityksella tai tekstiviestina Content Gateway palvelimen valityksella.
 *				Virheviestien lahetyksen edellytyksena on, ett� loppuasiakkaalla on olemassa toimivat yhteydet
 *				SMTP- ja/tai Content Gateway palvelimiin.
 *
 *
 *              PARAMETRIT:
 *                  - Ei input parametreja
 *
 *              PALUUARVOT:
 *                  - 0 ok-tilanteissa (UNIX/Linux piirre, joka ei ole viela kaytossa)
 *                  - 1 keskeytymistilanteissa
 *				
 *
 *              KESKEYTYKSEN HALLINTA:
 *                  - Keskeytystilanteessa TCP/IP socket yhteys suljetaan
 *					  ja lampotilatietojen tallennus tiedostoon lopetetaan.
 *
 *              UUDELLEEN KAYNNISTYS:
 *                  - Ei muita erityisvaatimuksia, mutta Rabbit -kortin ohjelma
 *					  taytyy olla paalla, jotta Daemon ohjelma pystyy muodostamaan
 *					  siihen TCP/IP socket yhteyden.
 *
 *
 *              14.01.2009 Jouni Virtanen
 *
 *
 **************************************************************************/


//
// Projektin omat header filet osa1
//
#include "vakiot.h"


//
// Microsoft Visual Studio kaantajassa pitaa kayttaa projektin asetuksissa. 
// /YX optiota = C/C++, precompiled headers, Create/Use Precompiled headers, Automatically Generate (/YX)
//
// Muuten tama #ifdef maarittely aiheuttaa virheen kaannosvaiheessa Microsoft Visual Studio ymparistossa
//
// Lisaksi socket kasittelyyn kaytetaan Winsock2 kirjastoa, joka on otettava linkkaukseen mukaan.
// Lisaa ws2_32.lib kirjasto projektin asetuksiin.
// Linker / Command Line / Additional Options / ws2_32.lib
//
// Lisaksi include filet otetaan mukaan.
// Lisaa projektin asetuksiin
// C/C++ / Command Line / /I../yleis_funktiot
//
#ifdef MICROSOFT_VISUAL_STUDIO
#include "stdafx.h"
#include <winsock2.h>
#else
#include <sys/socket.h>
#include <arpa/inet.h>
#include <errno.h>
#endif


//
// C -kaantajan omat header filet
//
#include <stdio.h>
#include <string.h>


//
// Projektin omat header filet osa2
//
#include "paivamaara_kasittely.h"
#include "tiedostonimi_kasittely.h"
#include "lista_kasittely.h"
#include "loki_kasittely.h"


//
// Rabbit -kortin ip -osoie
//
static char *pszRabbitIP;


//
// Rabbit -kortin socket portti
//
static char *pszRabbitPortti;


/***************************************************************************\
* FUNKTIO
*        setSocketTimeout
*		 (
*			int connectSocket, 
*			int milliseconds
*		 );
*
* INPUT
*        connectSocket	- Kasiteltava socket yhteys
*		 milliseconds	- Timeout arvo millisekunteina
*
* OUTPUT
*        Palauttaa :
*						0	 - Funktion suoritus onnistui
*						!= 0 - Funktion suoritus epaonnistui
*
* KUVAUS
*        Vaihtoehtoinen socketin timeout arvon asetus funktio.
*		 Funktio ei toimi Microsoft Visual Studio ymparistossa.
*
\***************************************************************************/
int setSocketTimeout
(
	int connectSocket, 
	int milliseconds
)
{
    struct timeval tv;

	tv.tv_sec = milliseconds / 1000;
	tv.tv_usec = ( milliseconds % 1000) * 1000;

    return setsockopt
			(
				connectSocket,
				SOL_SOCKET,
				SO_RCVTIMEO,
				(char *) &tv,
				sizeof(tv)
			);
}


/***************************************************************************\
* FUNKTIO
*        haeYmparistomuuttujat ();
*
* INPUT
*        Ei input parametreja.
*
* OUTPUT
*        Palauttaa :
*						0 - Funktion suoritus onnistui
*						1 - Funktion suoritus epaonnistui
*
* KUVAUS
*        Haetaan ohjelman tarvitsemat ymparistomuuttujat.
*
\***************************************************************************/
int haeYmparistomuuttujat()
{
	int		sPaluu = 0;
	char	szLokitulostus[200 + 1];


	// Haetaan Rabbit -kortin ip -osoite ymparistomuuttujasta
	if ((pszRabbitIP = getenv(RABBIT_KORTIN_IP)) == NULL)
	{
		sprintf(szLokitulostus, "%s: \"%s\" %s", YMPARISTOMUUTTUJAA, RABBIT_KORTIN_IP, EI_OLE_MAARITELTY);
		kirjoitaLokiTiedostoon(szLokitulostus);
		sPaluu = 1;
	}

	// Haetaan Rabbit -kortin ip -osoite ymparistomuuttujasta
	if ((pszRabbitPortti = getenv(RABBIT_KORTIN_PORTTI)) == NULL)
	{
		sprintf(szLokitulostus, "%s: \"%s\" %s", YMPARISTOMUUTTUJAA, RABBIT_KORTIN_PORTTI, EI_OLE_MAARITELTY);
		kirjoitaLokiTiedostoon(szLokitulostus);
		sPaluu = 1;
	}

	// Tallennetaan "lampotila data tiedostojen" -hakemisto ymparistomuuttujaan
	if (tallennaDatatiedostoHakemisto())
		sPaluu = 1;

	// Tallennetaan "loki tiedostojen" -hakemisto ymparistomuuttujaan
	if (tallennaLokitiedostoHakemisto())
		sPaluu = 1;

	return sPaluu;
}


/***************************************************************************\
* FUNKTIO
*        teeSocketAlustukset
*		 (
*			int *fd,
*			fd_set *readfds,
*			fd_set *writefds,
*			fd_set *exceptfds,
*			struct timeval *tv
*		 );
*
* INPUT
*		 Output parametrien osoitteet.
*
* OUTPUT
*        fd			- Muodostettu socket yhteys
*		 readfds	- Socket yhteydet, joihin kirjoitetaan
*		 writefds	- Socket yhteydet, joita luetaan
*		 exceptfds	- Socket yhteydet, joiden virheita valvotaan
*		 tv			- Socket yhteyden timeout arvo
*
*        Palauttaa :
*						0 - Funktion suoritus onnistui
*						1 - Funktion suoritus epaonnistui
*
* KUVAUS
*        Tekee socket kasittelyyn liittyvat alustukset.
*
\***************************************************************************/
int teeSocketAlustukset
(
	int *fd, 
	fd_set *readfds, 
	fd_set *writefds,
	fd_set *exceptfds,
	struct timeval *tv
)
{
#ifdef MICROSOFT_VISUAL_STUDIO
	WORD		wVersionRequested;
	WSADATA		wsaData;
	int			wsaerr;
#endif
	struct		sockaddr_in sa;
	char		szLokitulostus[200 + 1];


#ifdef MICROSOFT_VISUAL_STUDIO

	// Kaytetaan Winsock versiota 2.2
	wVersionRequested = MAKEWORD(2, 2);
	wsaerr = WSAStartup(wVersionRequested, &wsaData);

	if (wsaerr != 0)
	{
		// Winsock DLL ei loytynyt
		sprintf(szLokitulostus, "%s", WINSOCK_DLL_EI_LOYDY);
		kirjoitaLokiTiedostoon(szLokitulostus);
		return 1;
	}
	// Winsock DLL loytyi
	else
	{
		sprintf(szLokitulostus, "%s%s", WINSOCK_DLL_LOYTYI, wsaData.szSystemStatus);
		kirjoitaLokiTiedostoon(szLokitulostus);
	}

	// Varmistetaan, etta Winsock DLL tukee versiota 2.2
	if (LOBYTE(wsaData.wVersion) != 2 || HIBYTE(wsaData.wVersion) != 2 )
	{
		// Sopivaa Winsock DLL versiota ei loytynyt
		sprintf(szLokitulostus, "%s%u.%u", WINSOCK_DLL_TUKI_EI_LOYDY, LOBYTE(wsaData.wVersion), HIBYTE(wsaData.wVersion));
		kirjoitaLokiTiedostoon(szLokitulostus);
		WSACleanup();
		return 1; 
	}
	else
	{
		sprintf(szLokitulostus, "%s%u.%u", WINSOCK_DLL_TUKI_LOYTYI, LOBYTE(wsaData.wVersion), HIBYTE(wsaData.wVersion));
		kirjoitaLokiTiedostoon(szLokitulostus);
		sprintf(szLokitulostus, "%s%u.%u", WINSOCK_DLL_MAX_TUKI, LOBYTE(wsaData.wHighVersion), HIBYTE(wsaData.wHighVersion));
		kirjoitaLokiTiedostoon(szLokitulostus);
	}
#endif

	// Luodaan TCP socket
	if (( *fd = (int) socket ( PF_INET, SOCK_STREAM, IPPROTO_TCP )) < 0 )
		return 1;

	memset ( &sa, (char) NULL, sizeof ( sa )); /* Set structure full of zeros. */
	sa.sin_family = AF_INET; /* Address Family Inet = Protocol Family Inet. */
	sa.sin_port = htons ( atoi(pszRabbitPortti) ); /* Port number. */
	sa.sin_addr.s_addr = inet_addr ( pszRabbitIP ); /* Change dottet IP address to network byte order. */
 
	/*
	 * Here client send special SYN packet / packets to server and waits server to answer with ACK packet.
	 * After ACK is received client send FIN packet and connection is established.
	 */
	if ( connect ( *fd, (struct sockaddr *)&sa, sizeof ( sa )) < 0 )
	{
		sprintf(szLokitulostus, "%s", SOCKET_YHTEYS_VIRHE);
		kirjoitaLokiTiedostoon(szLokitulostus);

#ifdef MICROSOFT_VISUAL_STUDIO
		closesocket(*fd);
		WSACleanup();
#else
		close(*fd);
#endif
		return 1;
	}

	FD_ZERO(readfds);
	FD_SET(*fd, readfds);
	FD_ZERO(writefds);
	FD_ZERO(exceptfds);
	tv->tv_sec = DAEMON_SOCKET_TIMEOUT;
	tv->tv_usec = 0;

	return 0;
}


/***************************************************************************\
* FUNKTIO
*        tallennaLampotilatiedotTiedostoon
*		 (
*			int *sAlkioidenmaara, 
*			char *pszPaivamaara
*		 );
*
* INPUT
*        sAlkioidenmaara - Linkitetyssa listassa olevien alkioiden maara
*		 pszPaivamaara	 - Lampotilatiedoston paivamaara
*
* OUTPUT
*        Palauttaa :
*						0 - tietojen tallennus onnistui
*						1 - tietojen tallenus epaonnistui
*
* KUVAUS
*        Tallentaa kaikki lampotilatieto alkiot linkitetysta listasta
*		 tiedostoon. Jos tallennus epaonnistuu, niin alkioita kerataan
*		 listaan enintaan DAEMON_DATA_PUSKURI_MAX_KOKO verran. Taman
*		 jalkeen tallennusvirheet aiheuttavat funktion suorituksen
*		 epaonnistumisen. Laskee myos jokaisella kutsukerralla listan
*		 uusille alkioille lampotilojen keskiarvon ja tulostaa sen.
*
\***************************************************************************/
int tallennaLampotilatiedotTiedostoon(int *sAlkioidenmaara, char *pszPaivamaara)
{
	int			i, sPaluu = 0;
	double		dLampotila;
	LAMPOTILA_T *plampotilaTietue;
	char		szTiedostonimi[300 + 1];
	char		szLokitulostus[200 + 1];


	// Haetaan ensimmainen lampotila -alkio
	plampotilaTietue = haeEnsimmainenLampotila();
	i = 1;

	// Jos linkitetyssa listassa on enemman alkioita, kuin DAEMON_DATA_PUSKURI_KOKO
	// niin luetaan listaa niin kauan eteenpain, etta luettavia alkioita jaa taman verran
	if (*sAlkioidenmaara > DAEMON_DATA_PUSKURI_KOKO)
	{
		while ((*sAlkioidenmaara - i) != DAEMON_DATA_PUSKURI_KOKO)
		{
			// Haetaan seuraava lampotila -alkio
			plampotilaTietue = haeSeuraavaLampotila();
			i++;
		}
	}

	// Lasketaan lampotila -alkioille keskiarvo
	i = 0;
	dLampotila = 0;
	while (plampotilaTietue != NULL)
	{
		dLampotila += atof(plampotilaTietue->szLampotila);
		i++;

		// Haetaan seuraava lampotila -alkio
		plampotilaTietue = haeSeuraavaLampotila();
	}
	dLampotila /= i;

	sprintf(szLokitulostus, "%s%.1lf", DAEMON_KESKI_LAMPOTILA, dLampotila);
	kirjoitaLokiTiedostoon(szLokitulostus);

	// Muodostetaan kuluvan paivan mukainen lampotilatiedoston nimi
	muodostaLampotilaTiedostonimi(pszPaivamaara, szTiedostonimi);

	// Tallennetaan lampotilatiedot tiedostoon.
	//
	// Jos tallennus epaonnistui, niin tiedosto on ehka avattu esim. Excel -ohjelmaan
	// ja tasta johtuen ohjelma ei paase tallentamaan tietoja.
	//
	// Kerataan lampotilatietoja muistiin DAEMON_DATA_PUSKURI_MAX_KOKO:n asti
	// ja vasta sitten annetaan virheilmoitus, jos tallennus ei onnistu viela silloinkaan.
	//
	if (tallennaLampotilaTiedot(szTiedostonimi))
	{
		// Virhe, jos saavutettiin DAEMON_DATA_PUSKURI_MAX_KOKO
		if (*sAlkioidenmaara == DAEMON_DATA_PUSKURI_MAX_KOKO)
		{
			sPaluu = 1;
		}
	}
	else
	{
		*sAlkioidenmaara = 0;
	}

	return sPaluu;
}


/***************************************************************************\
* FUNKTIO
*		main();
*
* INPUT
*	Ei input parametreja.
*
* OUTPUT
*		0 - Ohjelman suoritus onnistui (UNIX/Linux piirre, joka ei ole viela kaytossa)
*		1 - Ohjelman suoritus epaonnistui
*
* KUVAUS
*	Ohjelman main funktio.
*
\***************************************************************************/
#ifdef MICROSOFT_VISUAL_STUDIO
int _tmain(int argc, _TCHAR* argv[])
#else
int main(int argc, char *argv[])
#endif
{
	char		szSocketpuskuri[DAEMON_SOCKET_PUSKURI_KOKO];
	int			fd, i, sPaluu;
	fd_set		readfds, writefds, exceptfds;
	struct		timeval tv;
	LAMPOTILA_T lampotilaTietue;
	char		szLokitulostus[200 + 1];


	// Haetaan ohjelman tarvitsemat ymparistomuuttujat
	// Poistutaan, jos epaonnistui
	if (haeYmparistomuuttujat())
		return 1;

	// Tehdaan socket alustukset
	if (teeSocketAlustukset(&fd, &readfds, &writefds, &exceptfds, &tv))
		return 1;

	i = 0;
	sPaluu = 0;
	while (1)
	{
		// Odotetaan Rabbit -kortin ohjelmalta lampotilatietoa
		sPaluu = select((char) NULL, &readfds, &writefds, &exceptfds, &tv);

		// Jos select funktiossa tuli timeout
		if (sPaluu == 0)
		{
			/* Socket has been disconnected */
			sprintf(szLokitulostus, "%s", SOCKET_SELECT_TIMEOUT);
			kirjoitaLokiTiedostoon(szLokitulostus);
			sPaluu = 1;
			break;
		}

		// Jos select funktiossa tuli virhe
		if(sPaluu < 0)
		{
			sprintf(szLokitulostus, "%s%d/%d", SOCKET_SELECT_VIRHE, sPaluu, errno);
			kirjoitaLokiTiedostoon(szLokitulostus);
			sPaluu = 1;
			break;
		}

		// Jos socketissa on luettavaa
		if(sPaluu > 0 && FD_ISSET(fd, &readfds))
		{
			// Luetaan tiedot socketista
			sPaluu = recv ( fd, szSocketpuskuri, DAEMON_SOCKET_PUSKURI_KOKO, 0 );

			// Jos recv funktiossa tuli virhe
			if (sPaluu < 0)
			{
				sprintf(szLokitulostus, "%s%d/%d", SOCKET_LUKU_VIRHE, sPaluu, errno);
				kirjoitaLokiTiedostoon(szLokitulostus);
				sPaluu = 1;
				break;
			}


			// Lahetetaan Rabbit kortin ohjelmalle OK kuittaus
			sPaluu = send ( fd, CLIENT_OHJELMAN_OK_KUITTAUS, (int) strlen(CLIENT_OHJELMAN_OK_KUITTAUS), 0 );

			// Jos send funktiossa tuli virhe
			if (sPaluu < (int) strlen(CLIENT_OHJELMAN_OK_KUITTAUS))
			{
				sprintf(szLokitulostus, "%s%d/%d", SOCKET_KIRJOITUS_VIRHE, sPaluu, errno);
				kirjoitaLokiTiedostoon(szLokitulostus);
				sPaluu = 1;
				break;
			}

			// Jos Rabbit -kortin lampotila -anturi toimii
			if (strcmp(szSocketpuskuri, RABBIT_KORTIN_ANTURI_EI_TOIMI))
			{
				// Viedaan Rabbit -kortin ohjelmalta saatu lampotila linkitettyyn listaan
				// aikaleimalla varustettuna
				strcpy(lampotilaTietue.szLampotila, szSocketpuskuri);
				strcpy(lampotilaTietue.szIposoite, pszRabbitIP);
				haeNykyinenpaiva(lampotilaTietue.szPaivamaara, sizeof(lampotilaTietue.szPaivamaara));
				haeNykyinenaika(lampotilaTietue.szKellonaika, sizeof(lampotilaTietue.szKellonaika));
				if (lisaaLampotilaListaan(&lampotilaTietue) == NULL)
				{
					kirjoitaLokiTiedostoon(LISTAAN_LISAYS_VIRHE);
					sPaluu = 1;
					break;
				}

				//printf("Lampotila: %.1f\n", atof(szSocketpuskuri));
				i++;


				// Jos linkitetyssa listassa on riittavasti lampotilatietoja, niin tallennetaan ne tiedostoon
				if (i % DAEMON_DATA_PUSKURI_KOKO == 0)
				{
					if (tallennaLampotilatiedotTiedostoon(&i, lampotilaTietue.szPaivamaara))
					{
						kirjoitaLokiTiedostoon(TIEDOSTOON_TALLENNUS_VIRHE);
						sPaluu = 1;
						break;
					}
				}
			}
			// Rabbit -kortin lampotila -anturi ei toimi
			else
			{
				kirjoitaLokiTiedostoon(RABBIT_KORTIN_ANTURI_VIRHE);
			}
		}
	}

// Suljetaan socket yhteys
#ifdef MICROSOFT_VISUAL_STUDIO
	closesocket(fd);
	WSACleanup();
#else
	// cleanup
	close(fd);
#endif

	return sPaluu;
}

