/*****************************************************************************
 * MODULI:		vakiot.h
 *
 * Kuvaus:		Projektin vakio ja konfigurointi tiedot.
 *				
 *
 *
 *              11.01.2009 Jouni Virtanen
 *
 *
 **************************************************************************/


/***************************************************************************/
/*** Projektissa kaytettavat vakiot                                      ***/
/***************************************************************************/

#define		WINDOWS							1
//#define		CYGWIN							1
#define		MICROSOFT_VISUAL_STUDIO			1
//#define		SUOMI							1
#define		ENGLANTI						1
#define		OHJELMAN_LOPETUS				"K"
#define		TABULOINTI						"\t"
#define		TUPLA_TABULOINTI				"\t\t"
#define		RIVIN_SIIRTO					"\n"
#define		TUPLA_RIVIN_SIIRTO				"\n\n"
#define		LAMPOTILATIETO_KENTAN_EROTIN	";"
#define		DATA_TIEDOSTO_HAKEMISTO			"DATA_TIEDOSTO_HAKEMISTO"
#define		DATA_TIEDOSTO_ALKU_OSA			"lampotilatiedot_"
#define		DATA_TIEDOSTO_TYYPPI			".csv"
#define		LOKI_TIEDOSTO_HAKEMISTO			"LOKI_TIEDOSTO_HAKEMISTO"
#define		LOKI_TIEDOSTO_ALKU_OSA			"lokitiedot_"
#define		LOKI_TIEDOSTO_TYYPPI			".txt"
#define		DAEMON_DATA_PUSKURI_KOKO		10
#define		DAEMON_DATA_PUSKURI_MAX_KOKO	(100 * DAEMON_DATA_PUSKURI_KOKO)
#define		DAEMON_SOCKET_PUSKURI_KOKO		100
#define		DAEMON_SOCKET_TIMEOUT			90
#define		RABBIT_KORTIN_IP				"RABBIT_KORTIN_IP"
#define		RABBIT_KORTIN_PORTTI			"RABBIT_KORTIN_PORTTI"
#define		CLIENT_OHJELMAN_OK_KUITTAUS		"OK"
#define		RABBIT_KORTIN_ANTURI_EI_TOIMI	"RABBIT KORTIN ANTURI EI TOIMI"

/***************************************************************************/
/*** Projektissa kaytettavat maa riippuvaiset virhe- ym. ilmoitukset     ***/
/***************************************************************************/
#ifdef SUOMI
#define		VIRHEELLINEN_MENUVALINTA			"Virheellinen menuvalinta"
#define		YMPARISTOMUUTTUJAA					"Ymparistomuuttujaa"
#define		EI_OLE_MAARITELTY					"ei ole maaritelty!"
#define		TIEDOSTO_VIRHE						"Lampotilatietojen haku epaonnistui! Tiedostosta:"
#define		TIEDOSTOA_EI_LOYDY					"Mittaustulos tiedostoa ei loytynyt"
#define		ALOITUS_PAIVA_LOPETUKSEN_JALKEEN	"Aloitus paiva ei voi olla lopetus paivan jalkeen"
#define		LISTAAN_LISAYS_VIRHE				"Linkitettyyn listaan lisays epaonnistui"
#define		TIEDOSTOON_TALLENNUS_VIRHE			"Lampotilatietojen tallennus tiedostoon epaonnistui"
#define		RABBIT_KORTIN_ANTURI_VIRHE			"Rabbit -kortin lampotila -anturi ei toimi!"
#define		WINSOCK_DLL_EI_LOYDY				"Winsock DLL tiedostoa ei loydy!"
#define		WINSOCK_DLL_LOYTYI					"Winsock DLL tiedosto loytyi, tila: "
#define		WINSOCK_DLL_TUKI_EI_LOYDY			"Winsock DLL tiedosto ei tue versiota: "
#define		WINSOCK_DLL_TUKI_LOYTYI				"Winsock DLL tiedosto tukee versiota: "
#define		WINSOCK_DLL_MAX_TUKI				"Winsock DLL tiedosto tukee enintaan versiota: "
#define		SOCKET_YHTEYS_VIRHE					"Socket yhteyden muodostus Rabbit -korttiin epaonnistui!"
#define		SOCKET_SELECT_TIMEOUT				"Timeout sockect select funktiossa"
#define		SOCKET_SELECT_VIRHE					"Virhe socket select funktiossa: "
#define		SOCKET_LUKU_VIRHE					"Virhe socket recv funktiossa: "
#define		SOCKET_KIRJOITUS_VIRHE				"Virhe socket send funktiossa: "
#define		DAEMON_KESKI_LAMPOTILA				"Tiedostoon tallennettujen lampotilojen keskiarvo on: "
#endif

#ifdef ENGLANTI
#define		VIRHEELLINEN_MENUVALINTA			"Erroneous menu selection"
#define		YMPARISTOMUUTTUJAA					"Environment variable"
#define		EI_OLE_MAARITELTY					"has not been defined!"
#define		TIEDOSTO_VIRHE						"Search for weather information has been failed! From file:"
#define		TIEDOSTOA_EI_LOYDY					"Sample results file not found"
#define		ALOITUS_PAIVA_LOPETUKSEN_JALKEEN	"Start day can not be after stop day"
#define		LISTAAN_LISAYS_VIRHE				"Adding to linked list failed"
#define		TIEDOSTOON_TALLENNUS_VIRHE			"Temperature information saving to file failed"
#define		RABBIT_KORTIN_ANTURI_VIRHE			"The temperature sensor of Rabbit card does not work!"
#define		WINSOCK_DLL_EI_LOYDY				"Winsock DLL file can't be found!"
#define		WINSOCK_DLL_LOYTYI					"Winsock DLL file found, status: "
#define		WINSOCK_DLL_TUKI_EI_LOYDY			"Winsock DLL file does not support the version: "
#define		WINSOCK_DLL_TUKI_LOYTYI				"Winsock DLL file supports the version: "
#define		WINSOCK_DLL_MAX_TUKI				"The highest version this Winsock DLL can support is: "
#define		SOCKET_YHTEYS_VIRHE					"Socket connection to Rabbit -card failed!"
#define		SOCKET_SELECT_TIMEOUT				"Timeout in sockect select function"
#define		SOCKET_SELECT_VIRHE					"Error in socket select function: "
#define		SOCKET_LUKU_VIRHE					"Error in socket recv function: "
#define		SOCKET_KIRJOITUS_VIRHE				"Error in socket send function: "
#define		DAEMON_KESKI_LAMPOTILA				"Average temperature for the saved temperature values is: "
#endif


