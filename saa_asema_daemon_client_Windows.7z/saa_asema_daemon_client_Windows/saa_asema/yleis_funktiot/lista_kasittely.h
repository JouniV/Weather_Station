/*****************************************************************************
 * MODULI:		lista_kasittely.h
 *
 * Kuvaus:		Header file lista_kasittely.c modulille.
 *				
 *
 *
 *              11.01.2009 Jouni Virtanen
 *
 *
 **************************************************************************/


//
// Lampotilatietojen tietuekuvaus
//
typedef struct LAMPOTILA_T {
	char	szIposoite[20 + 1];
	char	szKentanerotin_1[1 + 1];
	char	szPaivamaara[10 + 1];
	char	szKentanerotin_2[1 + 1];
	char	szKellonaika[8 + 1];
	char	szKentanerotin_3[1 + 1];
	char	szLampotila[5 + 1];
	double	Lampotila;
	struct LAMPOTILA_T *seuraavaLampotila;
} LAMPOTILA_T;


//
// Funktioiden esittelyt
//
LAMPOTILA_T *lisaaLampotilaListaan(LAMPOTILA_T *lampotilaTietue);
int tallennaLampotilaTiedot(char *pszTiedostonimi);
int haeLampotilaTiedot(char *pszTiedostonimi);
LAMPOTILA_T *haeEnsimmainenLampotila();
LAMPOTILA_T *haeSeuraavaLampotila();

