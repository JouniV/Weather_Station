/*****************************************************************************
 * MODULI:		tiedostonimi_kasittely.c
 *
 * Kuvaus:		Moduli sisaltaa yleiskayttoiset funktiot lampotilatiedostojen
 *				nimien kasittelyyn.
 *
 *
 *              14.01.2009 Jouni Virtanen
 *
 *
 **************************************************************************/


//
// C -kaantajan omat header filet
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


//
// Projektin omat header filet
//
#include "vakiot.h"
#include "loki_kasittely.h"


//
// Lampotila data tiedostojen hakemisto
//
static char *pszDatatiedostoHakemisto = NULL;


//
// Loki tiedostojen hakemisto
//
static char *pszLokitiedostoHakemisto = NULL;


/***************************************************************************\
* FUNKTIO
*        tallennaDatatiedostoHakemisto ();
*
* INPUT
*        Ei input parametreja.
*
* OUTPUT
*        Palauttaa :
*						0 - Funktion suoritus onnistui
*						1 - Funktion suoritus epaonnistui
*
* KUVAUS
*		Hakee "lampotila data tiedostojen" -hakemiston ymparistomuuttujasta
*		ja tallentaa modulin sisaiseen muuttujaan.
*
\***************************************************************************/
int tallennaDatatiedostoHakemisto()
{
	int		sPaluu = 0;
	char	szVirheilmoitus[200 + 1];

	// Haetaan "lampotila data tiedostojen" -hakemisto ymparistomuuttujasta
	if ((pszDatatiedostoHakemisto = getenv(DATA_TIEDOSTO_HAKEMISTO)) == NULL)
	{
		sprintf(szVirheilmoitus, "%s: \"%s\" %s", YMPARISTOMUUTTUJAA, DATA_TIEDOSTO_HAKEMISTO, EI_OLE_MAARITELTY);
		kirjoitaLokiTiedostoon(szVirheilmoitus);
		sPaluu = 1;
	}

	return sPaluu;
}


/***************************************************************************\
* FUNKTIO
*        muodostaLampotilaTiedostonimi
*		 (
*			char *pszPaiva,
*			char *pszTiedostonimi
*		 );
*
* INPUT
*        pszPaiva - Paivamaara, jonka lampotila tiedostonimi muodostetaan.
*					Paivamaara valitetaan muodossa pp.kk.vvvv
*
* OUTPUT
*        pszTiedostonimi - Muodostetun lampotilatiedoston nimi
*
* KUVAUS
*		Muodostaa paivamaaran mukaisen lampotilatiedoston nimen
*		hakemistopolulla varustettuna. Hakemistopolku otetaan taman modulin
*		sisaisesta muuttujasta pszDatatiedostoHakemisto. Tiedostonimen
*		alkuosa otetaan vakiosta DATA_TIEDOSTO_ALKU_OSA ja tiedoston
*		tyyppi vakiosta DATA_TIEDOSTO_TYYPPI.
*
\***************************************************************************/
void muodostaLampotilaTiedostonimi
(
	char *pszPaiva, 
	char *pszTiedostonimi
)
{
	
	if (pszDatatiedostoHakemisto != NULL)
	{
		sprintf
		(
			pszTiedostonimi,
#ifdef WINDOWS
			"%s\\%s%c%c%c%c%c%c%c%c%s", 
#else
			"%s/%s%c%c%c%c%c%c%c%c%s",
#endif
			pszDatatiedostoHakemisto, 
			DATA_TIEDOSTO_ALKU_OSA, 
			*(pszPaiva + 6),
			*(pszPaiva + 7),
			*(pszPaiva + 8),
			*(pszPaiva + 9),
			*(pszPaiva + 3),
			*(pszPaiva + 4),
			*(pszPaiva + 0),
			*(pszPaiva + 1),
			DATA_TIEDOSTO_TYYPPI
		);
	}
	else
	{
		strcpy(pszTiedostonimi, "");
	}
}


/***************************************************************************\
* FUNKTIO
*        tallennaLokitiedostoHakemisto ();
*
* INPUT
*        Ei input parametreja.
*
* OUTPUT
*        Palauttaa :
*						0 - Funktion suoritus onnistui
*						1 - Funktion suoritus epaonnistui
*
* KUVAUS
*		Hakee "loki tiedostojen" -hakemiston ymparistomuuttujasta
*		ja tallentaa modulin sisaiseen muuttujaan.
*
\***************************************************************************/
int tallennaLokitiedostoHakemisto()
{
	int		sPaluu = 0;
	char	szVirheilmoitus[200 + 1];

	// Haetaan "loki tiedostojen" -hakemisto ymparistomuuttujasta
	if ((pszLokitiedostoHakemisto = getenv(LOKI_TIEDOSTO_HAKEMISTO)) == NULL)
	{
		sprintf(szVirheilmoitus, "%s: \"%s\" %s", YMPARISTOMUUTTUJAA, LOKI_TIEDOSTO_HAKEMISTO, EI_OLE_MAARITELTY);
		kirjoitaLokiTiedostoon(szVirheilmoitus);
		sPaluu = 1;
	}

	return sPaluu;
}


/***************************************************************************\
* FUNKTIO
*        muodostaLokiTiedostonimi
*		 (
*			char *pszPaiva,
*			char *pszTiedostonimi
*		 );
*
* INPUT
*        pszPaiva - Paivamaara, jonka lokitiedosto nimi muodostetaan.
*					Paivamaara valitetaan muodossa pp.kk.vvvv
*
* OUTPUT
*        pszTiedostonimi - Muodostetun lokitiedoston nimi
*
* KUVAUS
*		Muodostaa paivamaaran mukaisen lokitiedoston nimen
*		hakemistopolulla varustettuna. Hakemistopolku otetaan taman modulin
*		sisaisesta muuttujasta pszLokitiedostoHakemisto. Tiedostonimen
*		alkuosa otetaan vakiosta LOKI_TIEDOSTO_ALKU_OSA ja tiedoston
*		tyyppi vakiosta LOKI_TIEDOSTO_TYYPPI.
*
\***************************************************************************/
void muodostaLokiTiedostonimi
(
	char *pszPaiva, 
	char *pszTiedostonimi
)
{
	
	if (pszLokitiedostoHakemisto != NULL)
	{
		sprintf
		(
			pszTiedostonimi,
#ifdef WINDOWS
			"%s\\%s%c%c%c%c%c%c%c%c%s",
#else
			"%s/%s%c%c%c%c%c%c%c%c%s",
#endif
			pszLokitiedostoHakemisto, 
			LOKI_TIEDOSTO_ALKU_OSA, 
			*(pszPaiva + 6),
			*(pszPaiva + 7),
			*(pszPaiva + 8),
			*(pszPaiva + 9),
			*(pszPaiva + 3),
			*(pszPaiva + 4),
			*(pszPaiva + 0),
			*(pszPaiva + 1),
			LOKI_TIEDOSTO_TYYPPI
		);
	}
	else
	{
		strcpy(pszTiedostonimi, "");
	}
}
