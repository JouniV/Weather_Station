/*****************************************************************************
 * MODULI:		paivamaara_kasittely.c
 *
 * Kuvaus:		Moduli sisaltaa yleiskayttoiset funktiot paivamaarien ja
 *				kellonaikojen kasittelyyn.
 *
 *
 *              14.01.2009 Jouni Virtanen
 *
 *
 **************************************************************************/

//
// Projektin omat header filet
//
#include "paivamaara_kasittely.h"


//
// C -kaantajan omat header filet
//
#include <stdio.h>
#include <string.h>
#include <time.h>



/***************************************************************************\
* FUNKTIO
*        haeNykyinenpaiva
*		 (
*			char *pszPaiva,
*			size_t puskuriKoko
*		 );
*
* INPUT
*        pszPaiva	 - Output parametrin osoite
*		 puskuriKoko - Output parametrin tilanvarauksen koko
*
* OUTPUT
*        pszPaiva - Nykyinen paiva muodossa pp.kk.vvvv
*
* KUVAUS
*		Palauttaa nykyisen paivan muodossa pp.kk.vvvv
*
\***************************************************************************/
void haeNykyinenpaiva(char *pszPaiva, size_t puskuriKoko)
{
	struct tm tim;
	time_t now;

	now = time(NULL);
	tim = *(localtime(&now));
	strftime(pszPaiva, puskuriKoko, "%d.%m.%Y\n", &tim);
	*(pszPaiva + 10) = (char) NULL;
}


/***************************************************************************\
* FUNKTIO
*        haeNykyinenaika
*		 (
*			char *pszAika,
*			size_t puskuriKoko
*		 );
*
* INPUT
*        pszAika	 - Output parametrin osoite
*		 puskuriKoko - Output parametrin tilanvarauksen koko
*
* OUTPUT
*        pszAika - Nykyinen aika muodossa hh:mm:ss
*
* KUVAUS
*		Palauttaa nykyisen ajan muodossa hh:mm:ss
*
\***************************************************************************/
void haeNykyinenaika(char *pszAika, size_t puskuriKoko)
{
	struct tm tim;
	time_t now;

	now = time(NULL);
	tim = *(localtime(&now));
	strftime(pszAika, puskuriKoko, "%H:%M:%S\n", &tim);
	*(pszAika + 8) = (char) NULL;
}


/***************************************************************************\
* FUNKTIO
*        onAamupaiva (char *pszAika);
*
* INPUT
*        pszAika - Aika muodossa hh:mm:ss
*
* OUTPUT
*        Palauttaa :
*						0 - Parametri on aamupaivan kellonaika
*						1 - Parametri ei ole aamupaivan kellonaika
*
* KUVAUS
*		Tarkistaa onko parametrina saatu aika aamupaivan kellonaika
*
\***************************************************************************/
int onAamupaiva(char *pszAika)
{
	int		sPaluu;
	char	szAika[8 + 1];

	strcpy(szAika, pszAika);
	szAika[5] = (char) NULL;
	if ( (strcmp(szAika, AAMU_PAIVA_ALARAJA) >= 0) && (strcmp(szAika, AAMU_PAIVA_YLARAJA) <= 0) )
		sPaluu = 0;
	else
		sPaluu = 1;

	return sPaluu;
}


/***************************************************************************\
* FUNKTIO
*        onIltapaiva (char *pszAika);
*
* INPUT
*        pszAika - Aika muodossa hh:mm:ss
*
* OUTPUT
*        Palauttaa :
*						0 - Parametri on iltapaivan kellonaika
*						1 - Parametri ei ole iltapaivan kellonaika
*
* KUVAUS
*		Tarkistaa onko parametrina saatu aika iltapaivan kellonaika
*
\***************************************************************************/
int onIltapaiva(char *pszAika)
{
	int		sPaluu;
	char	szAika[8 + 1];

	strcpy(szAika, pszAika);
	szAika[5] = (char) NULL;
	if ( (strcmp(szAika, ILTA_PAIVA_ALARAJA) >= 0) && (strcmp(szAika, ILTA_PAIVA_YLARAJA) <= 0) )
		sPaluu = 0;
	else
		sPaluu = 1;

	return sPaluu;
}


/***************************************************************************\
* FUNKTIO
*        onIlta (char *pszAika);
*
* INPUT
*        pszAika - Aika muodossa hh:mm:ss
*
* OUTPUT
*        Palauttaa :
*						0 - Parametri on illan kellonaika
*						1 - Parametri ei ole illan kellonaika
*
* KUVAUS
*		Tarkistaa onko parametrina saatu aika illan kellonaika
*
\***************************************************************************/
int onIlta(char *pszAika)
{
	int		sPaluu;
	char	szAika[8 + 1];

	strcpy(szAika, pszAika);
	szAika[5] = (char) NULL;
	if ( (strcmp(szAika, ILTA_ALARAJA) >= 0) && (strcmp(szAika, ILTA_YLARAJA) <= 0) )
		sPaluu = 0;
	else
		sPaluu = 1;

	return sPaluu;
}


/***************************************************************************\
* FUNKTIO
*        onYo (char *pszAika);
*
* INPUT
*        pszAika - Aika muodossa hh:mm:ss
*
* OUTPUT
*        Palauttaa :
*						0 - Parametri on yon kellonaika
*						1 - Parametri ei ole yon kellonaika
*
* KUVAUS
*		Tarkistaa onko parametrina saatu aika yon kellonaika
*
\***************************************************************************/
int onYo(char *pszAika)
{
	int		sPaluu;
	char	szAika[8 + 1];

	strcpy(szAika, pszAika);
	szAika[5] = (char) NULL;
	if ( (strcmp(szAika, YO_ALARAJA) >= 0) && (strcmp(szAika, YO_YLARAJA) <= 0) )
		sPaluu = 0;
	else
		sPaluu = 1;

	return sPaluu;
}

