/*****************************************************************************
 * MODULI:		tiedosto_kasittely.h
 *
 * Kuvaus:		Header file tiedosto_kasittely.c modulille.
 *				
 *
 *
 *              11.01.2009 Jouni Virtanen
 *
 *
 **************************************************************************/


//
// Tiedoston avaus moodi vakiot
//
#define		AVAA_LISAYS_MOODISSA	"a"
#define		AVAA_LUKU_MOODISSA		"r"


//
// Funktioiden esittelyt
//
FILE *avaaTiedosto(char *pszTiedostonimi, char *pszAvausmoodi);
void suljeTiedosto(FILE *fpTiedosto);
int kirjoitaTiedostoon(FILE *fpTiedosto, char *pszJono);
char *lueTiedostosta(FILE *fpTiedosto, char *pszJono, int sPuskurinkoko);
