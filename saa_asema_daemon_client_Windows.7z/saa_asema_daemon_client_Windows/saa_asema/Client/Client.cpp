/*****************************************************************************
 * OHJELMA:     client.c
 *
 * Kuvaus:          Saa-Asema.
 *                  Client ohjelmalla voi tutkia saa-aseman daemon ohjelman
 *                  tallentamia mittaustuloksia.
 *
 *              PARAMETRIT:
 *                  - Ei input parametreja
 *
 *              PALUUARVOT:
 *                  - 0 (menu funktioiden palauttama arvo, joka on nyt vakioarvo)
 *
 *              KESKEYTYKSEN HALLINTA:
 *                  - Ei keskeytyksen hallintaa, koska kyseessa on kayttoliittyma
 *
 *              UUDELLEEN KAYNNISTYS:
 *                  - Ei erityisia vaatimuksia
 *
 *
 *              11.01.2009 Jouni Virtanen
 *
 *
 **************************************************************************/


//
// Projektin omat header filet osa1
//
#include "vakiot.h"


//
// Microsoft Visual Studio kaantajassa pitaa kayttaa projektin asetuksissa
// /YX optiota = C/C++, precompiled headers, Create/Use Precompiled headers, Automatically Generate (/YX)
//
// Muuten tama #ifdef maarittely aiheuttaa virheen kaannosvaiheessa Microsoft Visual Studio ymparistossa
//
// Lisaksi include filet otetaan mukaan.
// Lisaa projektin asetuksiin
// C/C++ / Command Line / /I../yleis_funktiot
//
#ifdef MICROSOFT_VISUAL_STUDIO
#include "stdafx.h"
#endif

//
// C -kaantajan omat header filet
//
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//
// Projektin omat header filet osa2
//
#include "lista_kasittely.h"
#include "tiedostonimi_kasittely.h"
#include "paivamaara_kasittely.h"
#include "tiedosto_kasittely.h"



/***************************************************************************/
/*** Ohjelmassa kaytettavat maa riippuvaiset menuteksti vakiot           ***/
/***************************************************************************/
#ifdef SUOMI
#define		VIESTIT				"*********************  Viestit  **********************"
#define		VIESTI				"Viesti : "
#define		ALOITUS				"Tervetuloa, valitse toiminto luettelosta"
#define		ANNA_PAIVA			"Ole hyva, anna paivamaara muodossa pp.kk.vvvv : "
#define		ANNA_ALKU_PAIVA		"Ole hyva, anna alkamis paivamaara muodossa pp.kk.vvvv : "
#define		ANNA_LOPPU_PAIVA	"Loppumis paivamaara : "
#define		LAMPOTILA			"Lampotilat paivalle: "
#define		NAYTETTA			"naytetta"
#define		HAUISSA_NAYTETAAN	"Seuraavissa hauissa naytetaan"
#define		KOKOPAIVAN			"KOKOPAIVAN"
#define		AAMUPAIVAN			"AAMUPAIVAN"
#define		ILTAPAIVAN			"ILTAPAIVAN"
#define		ILLAN				"ILLAN"
#define		YON					"YON"
#define		LAMPOTILATIETOJA	"lampotilatietoja"
#define		MIN					"Minimi    = "
#define		MAX					"Maksimi   = "
#define		KESKIARVO			"Keskiarvo = "
#define		MENU_YLATEKSTI		"*****************  RYHMA-4 SAA-ASEMA  ****************"
#define		MENUVALINTA_1		"Hae yhden paivan saatiedot       = "
#define		MENUVALINTA_2		"Hae usemman paivan saatiedot     = "
#define		MENUVALINTA_3		"Nayta -Kaikki saatiedot          = "
#define		MENUVALINTA_4		"       Aamupaiva ("AAMU_PAIVA_ALARAJA " - " AAMU_PAIVA_YLARAJA") = "
#define		MENUVALINTA_5		"       Iltapaiva ("ILTA_PAIVA_ALARAJA " - " ILTA_PAIVA_YLARAJA") = "
#define		MENUVALINTA_6		"       Ilta      ("ILTA_ALARAJA       " - " ILTA_YLARAJA      ") = "
#define		MENUVALINTA_7		"       Yo        ("YO_ALARAJA         " - " YO_YLARAJA        ") = "
#define		MENUVALINTA_8		"Poistu                           = "
#define		MENU_OHJE			"Valintasi: "
#define		LOPETUS				"Kiitos hei, ohjelma sulkeutuu..."
#endif

#ifdef ENGLANTI
#define		VIESTIT				"***************       Messages          **************"
#define		VIESTI				"Message : "
#define		ALOITUS				"Welcome, pick operation from list"
#define		ANNA_PAIVA			"Please, enter date in format dd.mm.yyyy : "
#define		ANNA_ALKU_PAIVA		"Please, enter start date in format dd.mm.yyyy : "
#define		ANNA_LOPPU_PAIVA	"Please, enter end date : "
#define		LAMPOTILA			"Temperatures for the date: "
#define		NAYTETTA			"samples"
#define		HAUISSA_NAYTETAAN	"Next searches will be shown"
#define		KOKOPAIVAN			"WHOLEDAY"
#define		AAMUPAIVAN			"MORNING"
#define		ILTAPAIVAN			"DAY"
#define		ILLAN				"EVENING"
#define		YON					"NIGHT"
#define		LAMPOTILATIETOJA	"temperature"
#define		MIN					"Minimum = "
#define		MAX					"Maximum = "
#define		KESKIARVO			"Average = "
#define		MENU_YLATEKSTI		"*************** GROUP-4 WEATHER-STATION **************"
#define		MENUVALINTA_1		"Get one days weather          = "
#define		MENUVALINTA_2		"Get more days weathers        = "
#define		MENUVALINTA_3		"Show -All weathers            = "
#define		MENUVALINTA_4		"      Morning ("AAMU_PAIVA_ALARAJA " - " AAMU_PAIVA_YLARAJA") = "
#define		MENUVALINTA_5		"      Day     ("ILTA_PAIVA_ALARAJA " - " ILTA_PAIVA_YLARAJA") = "
#define		MENUVALINTA_6		"      Evening ("ILTA_ALARAJA       " - " ILTA_YLARAJA      ") = "
#define		MENUVALINTA_7		"      Night   ("YO_ALARAJA         " - " YO_YLARAJA        ") = "
#define		MENUVALINTA_8		"Exit                          = "
#define		MENU_OHJE			"Your choice: "
#define		LOPETUS				"Thanks good bye, program closing..."
#endif

/***************************************************************************/
/*** Ohjelmassa kaytettavat maa riippumattomat menuteksti vakiot         ***/
/***************************************************************************/
#define		MENU_ALATEKSTI      "******************************************************"


//
// Astemerkki
//
#ifdef WINDOWS
#define		ASTE_CHR			248
#else
#define		ASTE_CHR			176
#endif


/***************************************************************************/
/*** Ohjelmassa kaytettavat tietue kuvaukset                             ***/
/***************************************************************************/

//
// Menuvalintojen tietuekuvaus
//
// 1. kentta = menutekstirivin alkuun tulostettavat merkit
// 2. kentta = menuteksti
// 3. kentta = menuvalinta
// 4. kentta = suoritettavan menu funktion osoite
// 5. kentta = menutekstirivin loppuun tulostettavat merkit
//
typedef struct MENU_VALINNAT_T
{
	char	szEsitulostus[10 + 1];
	char	*pszMenuteksti;
	char	szMenuvalinta[10 + 1];
	char	szJalkitulostus[10 + 1];
	int		(*fpMenufunktio) (char *pszMenuvalinta);
} MENU_VALINNAT_T;


/***************************************************************************/
/*** Ohjelmassa kaytettavat globaalit muuttujat                          ***/
/***************************************************************************/

//
// Menuvalintojen taulukko, joka on alustettu ohjelmakoodin lopussa
//
extern MENU_VALINNAT_T menuvalinnat[];


//
// Menuvalikon viesti
//
char szMenuviesti[100 + 1];


//
// Menuun tulostettava minimi-, maksimi- ja keskilampotila
//
char szMinlampotila[50 + 1];
char szMaxlampotila[50 + 1];
char szKeskiarvolampotila[50 + 1];


//
// Talla muuttujalla ilmoitetaan, jos kayttaja on valinnut menusta ohjelman lopetus valinnan
//
char szLopetus[1 + 1];


//
// paivamaara tietue numeerisina arvoina vertailujen takia
//
struct paivamaara {
    int pp, kk, vvvv;
};


//
// Apu muuttujia lampotilatietojen kasittelya varten
//
int kuukaudenpaivat[13] = {0,31,28,31,30,31,30,31,31,30,31,30,31};

LAMPOTILA_T *plampotilaTietue;

LAMPOTILA_T tarkasteltava;
LAMPOTILA_T alin;
LAMPOTILA_T ylin;

double yhteensaLampotila;
double keskiarvoLampotila;
int mitatutLampotilat;

struct paivamaara syotetytPaivat[2];
struct paivamaara aikavalinLapikaynti;

int valittuAikavali;

void tyhjennaNaytto();


/***************************************************************************\
* FUNKTIO
*       LampotilaTietojenKasittely(char *pszTiedostoPaiva);
*
* INPUT
*		pszTiedostoPaiva - Lampotilatiedoston paivamaara muodossa pp.kk.vvvv
*
* OUTPUT
*       0 - Onnistunut suoritus
*       1 - Virhetilanne
*
* KUVAUS
*       Kay hakemassa lampotilatietoja tiedostosta ja ne kasitellaan rivi
*       rivilta. Tarkistetaan onko kyseinen mittaus alin tai ylin jos on
*       arvo tallennetaan globaaliin muuttujaan. Laskee yhteensa kaikki lampotilat
*       ja montako mittausta on suoritettu, keskiarvon laskemista varten.
*
\***************************************************************************/
int LampotilaTietojenKasittely(char *pszTiedostoPaiva)
{
    int     tarkasteltavaOnAikavalista;
    int     i;
    char    szLampotilaTiedosto[300 + 1];


	// Muodostetaan lampotilatiedoston nimi
	muodostaLampotilaTiedostonimi(pszTiedostoPaiva, szLampotilaTiedosto);

    if (haeLampotilaTiedot(szLampotilaTiedosto))
    {
    	printf("%s\n%s\n", TIEDOSTO_VIRHE, szLampotilaTiedosto);
        return 1;
    }
    yhteensaLampotila = 0;
    i = 0;
    tarkasteltava.Lampotila = 0;

    plampotilaTietue = haeEnsimmainenLampotila();

    if (plampotilaTietue != NULL)
    {
        sprintf(tarkasteltava.szPaivamaara, "%s", plampotilaTietue->szPaivamaara);

        printf(" * %s *\n", tarkasteltava.szPaivamaara);

        // haetaan uusia mittaustuloksia kunnes saavutaan NULL kohtaan
        while (plampotilaTietue != NULL)
        {
            tarkasteltava.Lampotila = atof(plampotilaTietue->szLampotila);
            sprintf(tarkasteltava.szPaivamaara, "%s", plampotilaTietue->szPaivamaara);
            sprintf(tarkasteltava.szKellonaika, "%s", plampotilaTietue->szKellonaika);

            if (valittuAikavali == 1)
            {
                if(!onAamupaiva(tarkasteltava.szKellonaika))
                    tarkasteltavaOnAikavalista = 1;
                else
                    tarkasteltavaOnAikavalista = 0;
            }
            else if (valittuAikavali == 2)
            {
                if(!onIltapaiva(tarkasteltava.szKellonaika))
                    tarkasteltavaOnAikavalista = 1;
                else
                    tarkasteltavaOnAikavalista = 0;
            }
            else if (valittuAikavali == 3)
            {
                if(!onIlta(tarkasteltava.szKellonaika))
                    tarkasteltavaOnAikavalista = 1;
                else
                    tarkasteltavaOnAikavalista = 0;
            }
            else if (valittuAikavali == 4)
            {
                if(!onYo(tarkasteltava.szKellonaika))
                    tarkasteltavaOnAikavalista = 1;
                else
                    tarkasteltavaOnAikavalista = 0;
            }
            else
            {
                tarkasteltavaOnAikavalista = 1;
            }

            if (tarkasteltavaOnAikavalista == 1)
            {
                printf("\t\t%s  %.1lf%cC\n", tarkasteltava.szKellonaika, tarkasteltava.Lampotila, ASTE_CHR);

                if (tarkasteltava.Lampotila < alin.Lampotila)
                {
                    alin.Lampotila = tarkasteltava.Lampotila;
                    strcpy(alin.szKellonaika, tarkasteltava.szKellonaika);
                    strcpy(alin.szPaivamaara, tarkasteltava.szPaivamaara);
                }

                if (tarkasteltava.Lampotila > ylin.Lampotila)
                {
                    ylin.Lampotila = tarkasteltava.Lampotila;
                    strcpy(ylin.szKellonaika, tarkasteltava.szKellonaika);
                    strcpy(ylin.szPaivamaara, tarkasteltava.szPaivamaara);
                }

                yhteensaLampotila += atof(plampotilaTietue->szLampotila);
                mitatutLampotilat += 1;
            }
            i++;
            plampotilaTietue = haeSeuraavaLampotila();
        }
    }
    return 0;
}


/***************************************************************************\
* FUNKTIO
*       yhdenPaivanSaatiedot(char *pszMenuvalinta);
*
* INPUT
*       pszMenuvalinta -  Kayttajan suorittama menuvalinta
*
* OUTPUT
*       0 - Onnistunut suoritus
*       1 - Virhetilanne
*
* KUVAUS
*       Pyytaa kayttajaa syottamaan yhden paivamaaran, muodossa pp.kk.vvvv
*       Kutsuu funktiota LampotilaTietojenKasittely
*       Asettaa menuviesteille arvoja mittaustuloksista
*
\***************************************************************************/
int yhdenPaivanSaatiedot(char *pszMenuvalinta)
{
    char	ch;
    char	kayttajanSyottamaPaiva[255];
    char	muistilappu[5];
    int		numero;
    char	tiedostoPaiva[10 + 1];


	mitatutLampotilat = 0;

    // paivamaaran syotto
    printf("%s\n", ANNA_PAIVA);
    fputs(" >> ", stdout);
    fflush(stdout);
    if ( fgets(kayttajanSyottamaPaiva, sizeof kayttajanSyottamaPaiva, stdin) )
    {
        sprintf(muistilappu, "%c%c", kayttajanSyottamaPaiva[0],kayttajanSyottamaPaiva[1]);
        if ( sscanf(muistilappu, "%d", &numero) == 1 )
            syotetytPaivat[0].pp = numero;

        sprintf(muistilappu, "%c%c", kayttajanSyottamaPaiva[3],kayttajanSyottamaPaiva[4]);
        if ( sscanf(muistilappu, "%d", &numero) == 1 )
            syotetytPaivat[0].kk = numero;

        sprintf(muistilappu, "%c%c%c%c", kayttajanSyottamaPaiva[6],kayttajanSyottamaPaiva[7], kayttajanSyottamaPaiva[8], kayttajanSyottamaPaiva[9]);
        if ( sscanf(muistilappu, "%d", &numero) == 1 )
            syotetytPaivat[0].vvvv = numero;
    }

    // Tyhjennetaan naytto
    tyhjennaNaytto();

    // tyhjennetaan alimpien ja ylimpien lampotilojen tiedot
    alin.Lampotila = 255;
    ylin.Lampotila = -255;
    strcpy(alin.szKellonaika, "");
    strcpy(ylin.szKellonaika, "");
    strcpy(alin.szPaivamaara, "");
    strcpy(ylin.szPaivamaara, "");

    // haetaan paivan mittaustulokset
	sprintf (tiedostoPaiva, "%02d.%02d.%04d", syotetytPaivat[0].pp, syotetytPaivat[0].kk, syotetytPaivat[0].vvvv);


    if (LampotilaTietojenKasittely(tiedostoPaiva) == 1)
    {
        sprintf(szMenuviesti, "%s", TIEDOSTOA_EI_LOYDY);
        ch=getchar();
		fflush(stdin);
        return 1;
    }
    // lasketaan haettujen lampotilatietojen keskiarvo
    keskiarvoLampotila = yhteensaLampotila / mitatutLampotilat;

    // asetetaan menuviesteihin sisallot
    sprintf(szMinlampotila, "%.1f%cC\t%s", alin.Lampotila, ASTE_CHR, alin.szKellonaika);
    sprintf(szMaxlampotila, "%.1f%cC\t%s", ylin.Lampotila, ASTE_CHR, ylin.szKellonaika);
    sprintf(szKeskiarvolampotila, "%.1f%cC", keskiarvoLampotila, ASTE_CHR);
    sprintf(szMenuviesti, "%s %d.%d.%d / %d %s", LAMPOTILA,
            syotetytPaivat[0].pp, syotetytPaivat[0].kk, syotetytPaivat[0].vvvv,
            mitatutLampotilat, NAYTETTA);

    ch=getchar();
	fflush(stdin);
	return 0;
}


/***************************************************************************\
* FUNKTIO
*       useanPaivanSaatiedot(char *pszMenuvalinta);
*
* INPUT
*       pszMenuvalinta -  Kayttajan suorittama menuvalinta
*
* OUTPUT
*       0 - Onnistunut suoritus
*       1 - Virhetilanne
*
* KUVAUS
*       Pyytaa kayttajaa syottamaan kaksi paivamaaraa (aloitus ja lopetus)
*       siirretaan syotetyt tiedot merkki kerrallaan apumuuttujaan
*       suoritetaan tarkistus etta syotetyt merkit ovat numeroita.
*       siirretaan paivamaarat tietueeseen.
*           [0] aloitus paiva
*           [1] lopetus paiva
*       Kutsuu funktiota LampotilaTietojenKasittely niin kauan kunnes kaikki
*       paivat annettujen paivien valilta on kayty lapi.
*       Asettaa menuviesteille arvoja mittaustuloksista
*
\***************************************************************************/
int useanPaivanSaatiedot(char *pszMenuvalinta)
{
    char	ch;
    char	kayttajanSyottamaPaiva[2][256];
    char	muistilappu[5];

    int		numero;
    int		kaikkiPaivatKaytyLapi = 0;
	char	tiedostoPaiva[10 + 1];

    mitatutLampotilat = 0;

    // Aloitus paivan syotto
    printf("%s\n", ANNA_ALKU_PAIVA);
    fputs(" >> ", stdout);
    fflush(stdout);
    if ( fgets(kayttajanSyottamaPaiva[0], sizeof kayttajanSyottamaPaiva[0], stdin) )
    {
        sprintf(muistilappu, "%c%c", kayttajanSyottamaPaiva[0][0],kayttajanSyottamaPaiva[0][1]);
        if ( sscanf(muistilappu, "%d", &numero) == 1 )
            syotetytPaivat[0].pp = numero;

        sprintf(muistilappu, "%c%c", kayttajanSyottamaPaiva[0][3],kayttajanSyottamaPaiva[0][4]);
        if ( sscanf(muistilappu, "%d", &numero) == 1 )
            syotetytPaivat[0].kk = numero;

        sprintf(muistilappu, "%c%c%c%c", kayttajanSyottamaPaiva[0][6],kayttajanSyottamaPaiva[0][7], kayttajanSyottamaPaiva[0][8], kayttajanSyottamaPaiva[0][9]);
        if ( sscanf(muistilappu, "%d", &numero) == 1 )
            syotetytPaivat[0].vvvv = numero;
    }

    // Lopetus paivan syotto
    printf("%s\n", ANNA_LOPPU_PAIVA);
    fputs(" >> ", stdout);
    fflush(stdout);
    if ( fgets(kayttajanSyottamaPaiva[1], sizeof kayttajanSyottamaPaiva[1], stdin) )
    {
        sprintf(muistilappu, "%c%c", kayttajanSyottamaPaiva[1][0],kayttajanSyottamaPaiva[1][1]);
        if ( sscanf(muistilappu, "%d", &numero) == 1 )
            syotetytPaivat[1].pp = numero;

        sprintf(muistilappu, "%c%c", kayttajanSyottamaPaiva[1][3],kayttajanSyottamaPaiva[1][4]);
        if ( sscanf(muistilappu, "%d", &numero) == 1 )
            syotetytPaivat[1].kk = numero;

        sprintf(muistilappu, "%c%c%c%c", kayttajanSyottamaPaiva[1][6],kayttajanSyottamaPaiva[1][7], kayttajanSyottamaPaiva[1][8], kayttajanSyottamaPaiva[1][9]);
        if ( sscanf(muistilappu, "%d", &numero) == 1 )
            syotetytPaivat[1].vvvv = numero;
    }

    // Tyhjennetaan naytto
    tyhjennaNaytto();

    // tarkistetaan etta jos aloitus paiva on ennen lopetuspaivaa, palautetaan virhe
    if (syotetytPaivat[0].pp >= syotetytPaivat[1].pp)
    {
        sprintf(szMenuviesti, "%s", ALOITUS_PAIVA_LOPETUKSEN_JALKEEN);
        return 1;
    }

    // kopioidaan aloitus paiva apu tietueeseen
    aikavalinLapikaynti = syotetytPaivat[0];

    // tyhjennetaan alimpien ja ylimpien lampotilojen tiedot
    alin.Lampotila = 255;
    ylin.Lampotila = -255;
    strcpy(alin.szKellonaika, "");
    strcpy(ylin.szKellonaika, "");
    strcpy(alin.szPaivamaara, "");
    strcpy(ylin.szPaivamaara, "");

    // haetaan ensimmaisen paivan mittaustulokset
	sprintf (tiedostoPaiva, "%02d.%02d.%04d", aikavalinLapikaynti.pp, aikavalinLapikaynti.kk, aikavalinLapikaynti.vvvv);
    if (LampotilaTietojenKasittely(tiedostoPaiva) == 1)
    {
        sprintf(szMenuviesti, "%s", TIEDOSTOA_EI_LOYDY);
        ch=getchar();
	fflush(stdin);
        return 1;
    }

    // haetaan mittaustuloksia niin kauan kunnes lapikaytava paiva = loppumis paiva
    while (kaikkiPaivatKaytyLapi == 0)
    {
        aikavalinLapikaynti.pp++;

        if (aikavalinLapikaynti.pp > kuukaudenpaivat[aikavalinLapikaynti.kk])
        {
            aikavalinLapikaynti.kk++;
            aikavalinLapikaynti.pp = 1;

            if (aikavalinLapikaynti.kk > 12)
            {
                aikavalinLapikaynti.vvvv++;
                aikavalinLapikaynti.kk = 1;
            }
        }

        // haetaan paivan mittaustulokset
		sprintf (tiedostoPaiva, "%02d.%02d.%04d", aikavalinLapikaynti.pp, aikavalinLapikaynti.kk, aikavalinLapikaynti.vvvv);
        if (LampotilaTietojenKasittely(tiedostoPaiva) == 1)
        {
            sprintf(szMenuviesti, "%s", TIEDOSTOA_EI_LOYDY);
            ch=getchar();
            fflush(stdin);
            return 1;
        }

        if (aikavalinLapikaynti.pp == syotetytPaivat[1].pp && aikavalinLapikaynti.kk == syotetytPaivat[1].kk && aikavalinLapikaynti.vvvv == syotetytPaivat[1].vvvv)
            kaikkiPaivatKaytyLapi = 1;
    }

    // lasketaan haettujen lampotilatietojen keskiarvo
    keskiarvoLampotila = yhteensaLampotila / mitatutLampotilat;

    // asetetaan menuviesteihin sisallot
    sprintf(szMinlampotila, "%.1f%cC\t%s\t%s", alin.Lampotila, ASTE_CHR, alin.szPaivamaara, alin.szKellonaika);
    sprintf(szMaxlampotila, "%.1f%cC\t%s\t%s", ylin.Lampotila, ASTE_CHR, ylin.szPaivamaara, ylin.szKellonaika);
    sprintf(szKeskiarvolampotila, "%.1f%cC", keskiarvoLampotila, ASTE_CHR);
    sprintf(szMenuviesti, "%s%d.%d.%d - %d.%d.%d / %d %s",
            LAMPOTILA,
            syotetytPaivat[0].pp, syotetytPaivat[0].kk, syotetytPaivat[0].vvvv,
            syotetytPaivat[1].pp, syotetytPaivat[1].kk, syotetytPaivat[1].vvvv,
            mitatutLampotilat,
            NAYTETTA);

    ch=getchar();
    fflush(stdin);
    return 0;
}


/***************************************************************************\
* FUNKTIO
*        kaikkiSaatiedot (char *pszMenuvalinta);
*
* INPUT
*        pszMenuvalinta -  Kayttajan suorittama menuvalinta
*
* OUTPUT
*        0 - Onnistunut suoritus
*	 1 - Virhetilanne
*
* KUVAUS
*        Asettaa valitunAikavalin nollaan eli kokopaivaksi.
*
\***************************************************************************/
int kaikkiSaatiedot(char *pszMenuvalinta)
{

	sprintf(szMenuviesti, "%s %s %s", HAUISSA_NAYTETAAN, KOKOPAIVAN, LAMPOTILATIETOJA);
	valittuAikavali = 0;
	return 0;
}


/***************************************************************************\
* FUNKTIO
*        aamupaivaSaatiedot (char *pszMenuvalinta);
*
* INPUT
*        pszMenuvalinta -  Kayttajan suorittama menuvalinta
*
* OUTPUT
*        0 - Onnistunut suoritus
*	 1 - Virhetilanne
*
* KUVAUS
*        Asettaa valitunAikavalin 1 eli aamupaivaksi.
*
\***************************************************************************/
int aamupaivaSaatiedot(char *pszMenuvalinta)
{

	sprintf(szMenuviesti, "%s %s %s", HAUISSA_NAYTETAAN, AAMUPAIVAN, LAMPOTILATIETOJA);
	valittuAikavali = 1;
	return 0;
}


/***************************************************************************\
* FUNKTIO
*        iltapaivaSaatiedot (char *pszMenuvalinta);
*
* INPUT
*        pszMenuvalinta -  Kayttajan suorittama menuvalinta
*
* OUTPUT
*        0 - Onnistunut suoritus
*	 1 - Virhetilanne
*
* KUVAUS
*        Asettaa valitunAikavalin 2 eli iltapaivaksi.
*
\***************************************************************************/
int iltapaivaSaatiedot(char *pszMenuvalinta)
{

	sprintf(szMenuviesti, "%s %s %s", HAUISSA_NAYTETAAN, ILTAPAIVAN, LAMPOTILATIETOJA);
    valittuAikavali = 2;
    return 0;
}


/***************************************************************************\
* FUNKTIO
*        iltaSaatiedot (char *pszMenuvalinta);
*
* INPUT
*        pszMenuvalinta -  Kayttajan suorittama menuvalinta
*
* OUTPUT
*        0 - Onnistunut suoritus
*	 1 - Virhetilanne
*
* KUVAUS
*        Asettaa valitunAikavalin 3 eli illaksi.
*
\***************************************************************************/
int iltaSaatiedot(char *pszMenuvalinta)
{

	sprintf(szMenuviesti, "%s %s %s", HAUISSA_NAYTETAAN, ILLAN, LAMPOTILATIETOJA);
    valittuAikavali = 3;
	return 0;
}


/***************************************************************************\
* FUNKTIO
*        yoSaatiedot (char *pszMenuvalinta);
*
* INPUT
*        pszMenuvalinta -  Kayttajan suorittama menuvalinta
*
* OUTPUT
*        0 - Onnistunut suoritus
*	 1 - Virhetilanne
*
* KUVAUS
*        Asettaa valitunAikavalin 4 eli yoksi.
*
\***************************************************************************/
int yoSaatiedot(char *pszMenuvalinta)
{

	sprintf(szMenuviesti, "%s %s %s", HAUISSA_NAYTETAAN, YON, LAMPOTILATIETOJA);
	valittuAikavali = 4;
    return 0;
}


/***************************************************************************\
* FUNKTIO
*        poistuMenusta (char *pszMenuvalinta);
*
* INPUT
*        pszMenuvalinta -  Kayttajan suorittama menuvalinta
*
* OUTPUT
*        0 - Onnistunut suoritus
*		 1 - Virhetilanne
*
* KUVAUS
*        Suorittaa menu funktion 5.
*
\***************************************************************************/
int poistuMenusta(char *pszMenuvalinta)
{
	printf("Kiitos, hei. Ohjelma sulkeutuu...\n");
	strcpy(szLopetus, OHJELMAN_LOPETUS);
	return 0;
}


/***************************************************************************\
* FUNKTIO
*        dummy (char *pszMenuvalinta);
*
* INPUT
*        pszMenuvalinta -  Kayttajan suorittama menuvalinta
*
* OUTPUT
*        Palauttaa vakioarvon 0.
*
* KUVAUS
*        Dummy funktio, joka tarvitaan sellaisille menuvalikon riveille,
*		 joilla ei ole menuvalintaa. Ko. menurivit ovat menun ulkoasua
*		 taydentavia riveja. Tata funktiota ei kutsuta.
*
\***************************************************************************/
int dummy(char *pszMenuvalinta)
{
	return 0;
}


/***************************************************************************\
* FUNKTIO
*        tyhjennaNaytto ();
*
* INPUT
*        Ei input parametreja.
*
* OUTPUT
*        Ei paluuarvoa.
*
* KUVAUS
*        Tyhjentaa nayton.
*
\***************************************************************************/
void tyhjennaNaytto()
{

#ifdef WINDOWS
        system("cls");
#elif CYGWIN
        system("cmd /c cls");
#else
        system("clear");
#endif
}


/***************************************************************************\
* FUNKTIO
*        tulostaMenu ();
*
* INPUT
*        Ei input parametreja.
*
* OUTPUT
*        Ei paluuarvoa.
*
* KUVAUS
*        Tulostaa kayttajan menun "menuvalinnat" -taulukosta, joka on
*		 alustettu ohjelmakoodin lopussa. Kutsuu kayttajan menuvalinnan
*		 mukaista funktiota taulukko alkion funktio pointterin avulla.
*
*		 Funktion suoritus lopetetaan, kun globaalin muuttujan szLopetus
*		 arvoksi on alustettu OHJELMAN_LOPETUS.
*
\***************************************************************************/
int tulostaMenu()
{
	MENU_VALINNAT_T *ptr;
	int sPaluuarvo, i;
	char szMenuvalinta[sizeof(ptr->szMenuvalinta)];


	// Pysytaan kayttajan menussa, niin kauan kun ei ole valittu ohjelman lopetusvalintaa
	while (strcmp(szLopetus, OHJELMAN_LOPETUS))
	{
		// Tyhjennetaan naytto
		tyhjennaNaytto();

		// Tulostetaan menuvalinta tekstit ja menuvalinnat "menuvalinnat" -taulukosta
		for (ptr = menuvalinnat, i = 1; ptr->fpMenufunktio; ptr++, i++)
		{
			// Menuviestin vakiotekstit ovat taulukon 2. alkiossa, tulostetaan ne erikseen
			if (i == 2)
			{
				printf("%s%s%s", ptr->pszMenuteksti, szMenuviesti, ptr->szJalkitulostus);
			}
			// Alkiossa 3 minimi lampotila
			else if (i == 3)
			{
				printf("%s%s%s", ptr->pszMenuteksti, szMinlampotila, ptr->szJalkitulostus);
			}
			// Alkiossa 4 maksimi lampotila
			else if (i == 4)
			{
				printf("%s%s%s", ptr->pszMenuteksti, szMaxlampotila, ptr->szJalkitulostus);
			}
			// Alkiossa 5 keskiarvo lampotila
			else if (i == 5)
			{
				printf("%s%s%s", ptr->pszMenuteksti, szKeskiarvolampotila, ptr->szJalkitulostus);
			}
			// Muiden alkioiden tulostus
			else
			{
				printf("%s%s%s%s", ptr->szEsitulostus, ptr->pszMenuteksti, ptr->szMenuvalinta, ptr->szJalkitulostus);
			}
		}


		// Tyhjennetaan menuviesti ja lampotila kentat
		strcpy(szMenuviesti, "");
		strcpy(szMinlampotila, "");
		strcpy(szMaxlampotila, "");
		strcpy(szKeskiarvolampotila, "");

		// Odotetaan kayttajan menuvalintaa
		fgets(szMenuvalinta, sizeof(szMenuvalinta - 1), stdin);

		// Kutsutaan kayttajan menuvalinnan mukaista funktiota
		for (ptr = menuvalinnat; ptr->fpMenufunktio; ptr++)
		{
			// Jos kayttajan antama menuvalinta loytyy "menuvalinnat" -taulukosta
			// niin kutsutaan menuvalinnan mukaista funktiota, muuten laitetaan virheilmoitus menuviestiin
			if (!strncmp(szMenuvalinta, ptr->szMenuvalinta, strlen(ptr->szMenuvalinta)))
			{
				sPaluuarvo = ptr->fpMenufunktio(szMenuvalinta);
				//strcpy(szMenuviesti, "");
				break;
			}
			else
			{
				strcpy(szMenuviesti, VIRHEELLINEN_MENUVALINTA);
			}
		}
	}

	return sPaluuarvo;
}


/***************************************************************************\
* FUNKTIO
*        haeYmparistomuuttujat ();
*
* INPUT
*        Ei input parametreja.
*
* OUTPUT
*        Palauttaa :
*						0 - Funktion suoritus onnistui
*						1 - Funktion suoritus epaonnistui
*
* KUVAUS
*        Haetaan ohjelman tarvitsemat ymparistomuuttujat.
*
\***************************************************************************/
int haeYmparistomuuttujat()
{
	int sPaluu = 0;


	// Tallennetaan "lampotila data tiedostojen" -hakemisto ymparistomuuttujaan
	if (tallennaDatatiedostoHakemisto())
		sPaluu = 1;

	return sPaluu;
}


/***************************************************************************\
* FUNKTIO
*		main();
*
* INPUT
*	Ei input parametreja.
*
* OUTPUT
*		0 - (menu funktioiden palauttama arvo, joka on nyt vakioarvo)
*
* KUVAUS
*	Ohjelman main funktio.
*
\***************************************************************************/
#ifdef MICROSOFT_VISUAL_STUDIO
int _tmain(int argc, _TCHAR* argv[])
#else
int main(int argc, char *argv[])
#endif
{
	int sPaluuarvo;


	// Tallennetaan "lampotila data tiedostojen" -hakemisto ymparistomuuttujaan
	// Poistutaan, jos epaonnistui
	if (haeYmparistomuuttujat())
		return 1;

	// ALustetaan szLopetus muuttuja tyhjaksi ja kaynnistetaan ohjelman suoritus
	strcpy(szLopetus, "");
	sprintf(szMenuviesti, "%s", ALOITUS);
	sPaluuarvo = tulostaMenu();

	// Tyhjennetaan naytto
	tyhjennaNaytto();

	return sPaluuarvo;
}


//
// Ohjelmassa kaytettavat menutekstit, menuvalinnat ja menu funktiot
//
// 1. kentta = menutekstirivin alkuun tulostettavat merkit
// 2. kentta = menuteksti
// 3. kentta = menuvalinta
// 4. kentta = suoritettavan menu funktion osoite
//				- Kayta dummy funktiota riveilla, joilla ei ole menuvalintaa
//				- Nama rivit ovat menun ulkoasua taydentavia riveja
//
// 5. kentta = menutekstirivin loppuun tulostettavat merkit
//
MENU_VALINNAT_T menuvalinnat[] =
{
	{ "",           VIESTIT,	" ", TUPLA_RIVIN_SIIRTO,    dummy		},
	{ "",		VIESTI,         " ", TUPLA_RIVIN_SIIRTO,    dummy		},
	{ "",		MIN,            " ", RIVIN_SIIRTO,          dummy		},
	{ "",		MAX,            " ", RIVIN_SIIRTO,          dummy		},
	{ "",		KESKIARVO,	" ", TUPLA_RIVIN_SIIRTO,    dummy		},
	{ "",		MENU_YLATEKSTI,	" ", TUPLA_RIVIN_SIIRTO,    dummy		},
	{ TABULOINTI,   MENUVALINTA_1,	"1", RIVIN_SIIRTO,          yhdenPaivanSaatiedot},
	{ TABULOINTI,   MENUVALINTA_2,	"2", TUPLA_RIVIN_SIIRTO,    useanPaivanSaatiedot},
	{ TABULOINTI,   MENUVALINTA_3,	"3", RIVIN_SIIRTO,          kaikkiSaatiedot     },
	{ TABULOINTI,   MENUVALINTA_4,	"4", RIVIN_SIIRTO,          aamupaivaSaatiedot  },
	{ TABULOINTI,   MENUVALINTA_5,	"5", RIVIN_SIIRTO,          iltapaivaSaatiedot  },
	{ TABULOINTI,   MENUVALINTA_6,	"6", RIVIN_SIIRTO,          iltaSaatiedot	},
	{ TABULOINTI,   MENUVALINTA_7,	"7", TUPLA_RIVIN_SIIRTO,    yoSaatiedot         },
	{ TABULOINTI,   MENUVALINTA_8,	"x", TUPLA_RIVIN_SIIRTO,    poistuMenusta	},
	{ "",           MENU_ALATEKSTI,	" ", TUPLA_RIVIN_SIIRTO,    dummy		},
	{ TABULOINTI,   MENU_OHJE,      " ", "",                    dummy		},
	{ "",           "",             " ", "",                    NULL		}
};
