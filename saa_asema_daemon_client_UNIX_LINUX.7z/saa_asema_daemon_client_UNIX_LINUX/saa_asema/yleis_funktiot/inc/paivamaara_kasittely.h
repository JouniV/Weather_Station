/*****************************************************************************
 * MODULI:		paivamaara_kasittely.h
 *
 * Kuvaus:		Header file paivamaara_kasittely.c modulille.
 *				
 *
 *
 *              14.01.2009 Jouni Virtanen
 *
 *
 **************************************************************************/


//
// C -kaantajan omat header filet
//
#include <stdlib.h>


//
// Alaraja- ja ylaraja vakiot vuorokauden eri ajoille tunteina ja minuutteina
//
#define	AAMU_PAIVA_ALARAJA		"06:00"
#define	AAMU_PAIVA_YLARAJA		"11:59"
#define	ILTA_PAIVA_ALARAJA		"12:00"
#define	ILTA_PAIVA_YLARAJA		"17:59"
#define	ILTA_ALARAJA			"18:00"
#define	ILTA_YLARAJA			"23:59"
#define	YO_ALARAJA				"00:00"
#define	YO_YLARAJA				"05:59"


//
// Funktioiden esittelyt
//
void haeNykyinenpaiva(char *pszPaiva, size_t puskuriKoko);
void haeNykyinenaika(char *pszAika, size_t puskuriKoko);
int onAamupaiva(char *pszAika);
int onIltapaiva(char *pszAika);
int onIlta(char *pszAika);
int onYo(char *pszAika);


