/*****************************************************************************
 * MODULI:		loki_kasittely.h
 *
 * Kuvaus:		Header file loki_kasittely.c modulille.
 *				
 *
 *
 *              28.01.2009 Jouni Virtanen
 *
 *
 **************************************************************************/

//
// Funktioiden esittelyt
//
int kirjoitaLokiTiedostoon(char *pszJono);
