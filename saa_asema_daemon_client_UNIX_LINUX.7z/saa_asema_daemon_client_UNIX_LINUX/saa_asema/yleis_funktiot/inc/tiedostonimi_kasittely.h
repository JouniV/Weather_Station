/*****************************************************************************
 * MODULI:		tiedostonimi_kasittely.h
 *
 * Kuvaus:		Header file tiedostonimi_kasittely.c modulille.
 *				
 *
 *
 *              14.01.2009 Jouni Virtanen
 *
 *
 **************************************************************************/


//
// Funktioiden esittelyt
//
int tallennaDatatiedostoHakemisto();
void muodostaLampotilaTiedostonimi(char *pszPaiva, char *pszTiedostonimi);
int tallennaLokitiedostoHakemisto();
void muodostaLokiTiedostonimi(char *pszPaiva, char *pszTiedostonimi);

