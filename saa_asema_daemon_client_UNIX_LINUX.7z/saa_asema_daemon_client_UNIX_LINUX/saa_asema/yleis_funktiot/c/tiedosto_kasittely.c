/*****************************************************************************
 * MODULI:		tiedosto_kasittely.c
 *
 * Kuvaus:		Moduli sisaltaa yleiskayttoiset funktiot tiedostojen
 *				kasittelyyn. Moduli sisaltaa seuraavat ominaisuudet
 *				tiedostojen kasittelylle :
 *				
 *					- Avaus ja sulku
 *					- Luku ja kirjoitus
 *
 *
 *              11.01.2009 Jouni Virtanen
 *
 *
 **************************************************************************/


//
// C -kaantajan omat header filet
//
#include <stdio.h>


//
// Projektin omat header filet
//
#include "tiedosto_kasittely.h"


/***************************************************************************\
* FUNKTIO
*        avaaTiedosto (char *pszTiedostonimi, char *pszAvausmoodi);
*
* INPUT
*        pszTiedostonimi -  Tiedoston nimi hakemistopolkuineen, joka avataan
*		 pszAvausmoodi	 -  Tiedoston avausmoodi
*
* OUTPUT
*        Palauttaa :
*						!= NULL - tiedoston avaus onnistui
*						NULL	- tiedoston avaus epaonnistui
*
* KUVAUS
*        Avaa tiedoston parametrin mukaisessa moodissa.
*
\***************************************************************************/
FILE *avaaTiedosto(char *pszTiedostonimi, char *pszAvausmoodi)
{

	return fopen(pszTiedostonimi, pszAvausmoodi);
}


/***************************************************************************\
* FUNKTIO
*        suljeTiedosto (FILE *fpTiedosto);
*
* INPUT
*        fpTiedosto -  Tiedosto -osoitin avoinna olevaan tiedostoon
*		
* OUTPUT
*        Palauttaa
*		
*		 Ei paluuarvoa
*
* KUVAUS
*        Sulkee avoinna olevan tiedoston.
*
\***************************************************************************/
void suljeTiedosto(FILE *fpTiedosto)
{

	fclose(fpTiedosto);
}


/***************************************************************************\
* FUNKTIO
*        kirjoitaTiedostoon (FILE *fpTiedosto, char *pszJono);
*
* INPUT
*        fpTiedosto		 -  Tiedosto -osoitin avoinna olevaan tiedostoon
*		 pszJono		 -  Tiedostoon kirjoitettava rivi
*
* OUTPUT
*        Palauttaa :
*						>= 0 - tiedostoon kirjoitus onnistui
*						< 0	 - tiedostoon kirjoitus epaonnistui
*
* KUVAUS
*        Kirjoittaa parametrin mukaisen rivin tiedostoon.
*
\***************************************************************************/
int kirjoitaTiedostoon(FILE *fpTiedosto, char *pszJono)
{

	return fputs(pszJono, fpTiedosto);
}


/***************************************************************************\
* FUNKTIO
*        lueTiedostosta (FILE *fpTiedosto, char *pszJono);
*
* INPUT
*        fpTiedosto		 -  Tiedosto -osoitin avoinna olevaan tiedostoon
*		 pszJono		 -  Tiedostosta luettava rivi
*
* OUTPUT
*        Palauttaa :
*						!= NULL - tiedostosta luku onnistui
*						NULL    - tiedostosta luku epaonnistui tai EOF
*
* KUVAUS
*        Lukee yhden rivin tiedostosta.
*
\***************************************************************************/
char *lueTiedostosta(FILE *fpTiedosto, char *pszJono, int sPuskurinkoko)
{

	return fgets(pszJono, sPuskurinkoko, fpTiedosto);
}
