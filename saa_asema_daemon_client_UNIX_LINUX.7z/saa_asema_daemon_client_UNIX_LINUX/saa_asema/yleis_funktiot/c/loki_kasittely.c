/*****************************************************************************
 * MODULI:		loki_kasittely.c
 *
 * Kuvaus:		Moduli sisaltaa yleiskayttoiset funktiot lokitietojen
 *				kasittelyyn.
 *				
 *					- Lokitiedostoon kirjoitus
 *
 *
 *              28.01.2009 Jouni Virtanen
 *
 *
 **************************************************************************/


//
// C -kaantajan omat header filet
//
#include <stdio.h>
#include <string.h>
#include <time.h>


//
// Projektin omat header filet
//
#include "paivamaara_kasittely.h"
#include "tiedostonimi_kasittely.h"
#include "tiedosto_kasittely.h"


/***************************************************************************\
* FUNKTIO
*        kirjoitaLokiTiedostoon (char *pszJono);
*
* INPUT
*        pszJono - Lokitiedostoon kirjoitettava rivi ilman rivinsiirto merkkia
*
* OUTPUT
*        0 - Funktion suoritus onnistui
*		 1 - Funktion suoritus epaonnistui
*
* KUVAUS
*		Funktio kirjoittaa kuluvan paivan mukaiseen lokitiedostoon
*		parametrina saadun merkkijonon. Jos lokitiedostoon kirjoitus
*		epaonnistuu, niin merkkijono tulostetaan naytolle.
*
\***************************************************************************/
int kirjoitaLokiTiedostoon(char *pszJono)
{
	char	szPaivamaara[10 + 1];
	char	szKellonaika[8 + 1];
	char	szTiedostonimi[300 + 1];
	char	szJono[200 + 1];
	FILE	*fpTiedosto;
	int		sPaluu = 0;

	// Haetaan kuluva paiva ja kellonaika
	haeNykyinenpaiva(szPaivamaara, sizeof(szPaivamaara));
	haeNykyinenaika(szKellonaika, sizeof(szKellonaika));

	// Muodostetaan kuluvan paivan mukainen lokitiedoston nimi
	muodostaLokiTiedostonimi(szPaivamaara, szTiedostonimi);

	// Jos lokitiedoston nimen muodostus onnistui
	if (strlen(szTiedostonimi))
	{
		// Avataan tiedosto peraan kirjoitus moodissa
		if ((fpTiedosto = avaaTiedosto(szTiedostonimi, AVAA_LISAYS_MOODISSA)) != NULL)
		{
			// Koostetaan tiedostoon kirjoitettava loki rivi
			sprintf(szJono, "%s  %s\n", szKellonaika, pszJono);
			
			// Kirjoitetaan lokirivi tiedostoon
			if (kirjoitaTiedostoon(fpTiedosto, szJono) < 0)
			{
				printf("%s\n", szJono);
				sPaluu = 1;
			}

			// Suljetaan tiedosto
			suljeTiedosto(fpTiedosto);
		}
	}
	else
	{
		printf("%s\n", pszJono);
	}

	return sPaluu;
}
