/*****************************************************************************
 * MODULI:		lista_kasittely.c
 *
 * Kuvaus:		Moduli sisaltaa yleiskayttoiset funktiot lampotilatietojen
 *				kasittelyyn. Moduli sisaltaa seuraavat ominaisuudet
 *				lampotilatietojen kasittelylle :
 *				
 *					- Tallennus tiedostoon CSV formaatissa
 *					- Lukeminen CSV formaatissa olevasta tiedostosta
 *					- Dynaaminen muistin varaus
 *					- Tietorakenteena yhteen suuntaan linkitetty lista
 *					- Tietojen hakeminen linkitetysta listasta
 *
 *
 *              11.01.2009 Jouni Virtanen
 *
 *
 **************************************************************************/


//
// C -kaantajan omat header filet
//
#include <stdio.h>
#include <string.h>
#include <malloc.h>


//
// Projektin omat header filet
//
#include "vakiot.h"
#include "lista_kasittely.h"
#include "tiedosto_kasittely.h"


//
// Osoitin linkitetyn listan ensimmaiseen, viimeiseen ja nykyiseen lampotila -alkioon
//
static LAMPOTILA_T *ensimmainenLampotila, *viimeinenLampotila, *nykyinenLampotila = NULL;


/***************************************************************************\
* FUNKTIO
*        lisaaLampotilaListaan (LAMPOTILA_T *lampotilaTietue);
*
* INPUT
*        lampotilaTietue -  Linkitettyyn listaan lisattavan lampotila tietueen
*							osoite.
*
* OUTPUT
*        Palauttaa linkitettyyn listaan lisatyn lampotila -alkion osoitteen.
*
* KUVAUS
*        Varaa dynaamisesti muistia uudelle lampotila -alkiolle ja lisaa
*		 alkion linkitettyyn listaan.
*
\***************************************************************************/
LAMPOTILA_T *lisaaLampotilaListaan(LAMPOTILA_T *lampotilaTietue)
{
	LAMPOTILA_T *tilanvaraus;


	// Varataan dynaamisesti muistia uudelle lampotila -alkiolle
	tilanvaraus = (LAMPOTILA_T *) malloc(sizeof(LAMPOTILA_T));

	// Jos tilanvaraus onnistui
	if (tilanvaraus != NULL)
	{
		// Kopioidaan lampotilatietueen data lampotila -alkioon
		*tilanvaraus = *lampotilaTietue;

		// Jos linkitetty lista on tyhja -> kyseessa ensimmainen lisays, listaan listan alkuun
		if (ensimmainenLampotila == NULL)
		{
			// Otetaan ensimmaisen alkion osoite talteen
			ensimmainenLampotila = tilanvaraus;
			ensimmainenLampotila->seuraavaLampotila = NULL;
		}
		// Lisataan listan peraan
		else
		{
			viimeinenLampotila->seuraavaLampotila = tilanvaraus;
		}
	}
	
	// Pidetaan viimeisen lampotila -alkion osoite ajantasalla
	viimeinenLampotila = tilanvaraus;
	viimeinenLampotila->seuraavaLampotila = NULL;

	return tilanvaraus;
}


/***************************************************************************\
* FUNKTIO
*        tallennaLampotilaTiedot (char *pszTiedostonimi);
*
* INPUT
*        pszTiedostonimi -  Tiedoston nimi hakemistopolkuineen, johon 
*							tiedot tallennetaan.
*
* OUTPUT
*        Palauttaa :
*						0 - tietojen tallennus onnistui
*						1 - tietojen tallenus epaonnistui
*
* KUVAUS
*        Tallentaa kaikki lampotilatieto alkiot linkitetysta listasta
*		 tiedostoon.
*
\***************************************************************************/
int tallennaLampotilaTiedot(char *pszTiedostonimi)
{
	LAMPOTILA_T *tilanvaraus;
	char		szLampotila[sizeof(tilanvaraus->szLampotila)];
	char		*pszDesimaalipiste;
	FILE		*fpTiedosto;
	int			sPaluu = 1;
	char		szJono[ 
							 sizeof(tilanvaraus->szIposoite)	+ 
							 sizeof(tilanvaraus->szPaivamaara)	+ 
							 sizeof(tilanvaraus->szKellonaika)	+ 
							 sizeof(tilanvaraus->szLampotila)	+ 
						(3 * sizeof(tilanvaraus->szKentanerotin_1)) ];


	// Avataan tiedosto peraan kirjoitus moodissa
	if ((fpTiedosto = avaaTiedosto(pszTiedostonimi, AVAA_LISAYS_MOODISSA)) != NULL)
	{
		// Haetaan ensimmainen lampotila -alkio
		tilanvaraus = ensimmainenLampotila;
		nykyinenLampotila = tilanvaraus;

		// Kaydaan linkitettya listaa lapi niin kauan kun siina on lampotila -alkioita
		while (tilanvaraus)
		{
			// Muutetaan lampotilassa oleva desimaalipilkku desimaalipisteeksi
			strcpy(szLampotila, tilanvaraus->szLampotila);
			pszDesimaalipiste = strstr(szLampotila, ".");
			*pszDesimaalipiste = ',';

			// Koostetaan tiedostoon kirjoitettava lampotilatieto rivi
			sprintf(
						szJono, "%s%s%s%s%s%s%s\n",
						tilanvaraus->szIposoite, 
						LAMPOTILATIETO_KENTAN_EROTIN, 
						tilanvaraus->szPaivamaara, 
						LAMPOTILATIETO_KENTAN_EROTIN, 
						tilanvaraus->szKellonaika, 
						LAMPOTILATIETO_KENTAN_EROTIN, 
						szLampotila
					);
			
			// Kirjoitetaan lampotilatieto rivi tiedostoon
			if (kirjoitaTiedostoon(fpTiedosto, szJono) < 0)
				break;

			// Siirrytaan seuraavaan lampotila -alkioon
			tilanvaraus = tilanvaraus->seuraavaLampotila;

			// Vapautetaan edellisen alkion tilanvaraus
			free(nykyinenLampotila);

			// Otetaan alkion osoite talteen, jotta tila voidaan vapauttaa tuossa ylapuolella
			nykyinenLampotila = tilanvaraus;
		}

		// Suljetaan tiedosto
		suljeTiedosto(fpTiedosto);

		// Nullataan linkitetyn listan pointterit
		ensimmainenLampotila = NULL;
		viimeinenLampotila = NULL;
		nykyinenLampotila = NULL;

		sPaluu = 0;
	}

	return sPaluu;
}


/***************************************************************************\
* FUNKTIO
*        erotaLampotilakentat (char *pszJono, LAMPOTILA_T *lampotilaTietue);
*
* INPUT
*        pszJono		 - lampotilatiedostosta luettu rivi
*		 lampotilaTietue - output parametrin osoite
*
* OUTPUT
*        lampotilaTietue - pszJono parametrista siirretyt lampotila tiedot
*
* KUVAUS
*        Siirtaa lampotilatiedostosta luetun pszJono rivin tiedot
*		 lampotilaTietue output parametriin.
*
\***************************************************************************/
void erotaLampotilakentat(char *pszJono, LAMPOTILA_T *lampotilaTietue)
{
	int		sKenttanumero;
	char	*pszErotinmerkki, *pszDesimaalipilkku;
	char	szJono[ 		 sizeof(lampotilaTietue->szIposoite)	+ 
							 sizeof(lampotilaTietue->szPaivamaara)	+ 
							 sizeof(lampotilaTietue->szKellonaika)	+ 
							 sizeof(lampotilaTietue->szLampotila)	+ 
						(3 * sizeof(lampotilaTietue->szKentanerotin_1)) ];

	strcpy(szJono, pszJono);
	sKenttanumero = 1;

	while ((pszErotinmerkki = strstr(szJono, LAMPOTILATIETO_KENTAN_EROTIN)) != NULL)
	{
		switch (sKenttanumero)
		{
			case 1:
				*pszErotinmerkki = (char) NULL;
				strcpy(lampotilaTietue->szIposoite, szJono);
				strcpy(szJono, pszErotinmerkki + 1);
				sKenttanumero++;
				break;

			case 2:
				*pszErotinmerkki = (char) NULL;
				strcpy(lampotilaTietue->szPaivamaara, szJono);
				strcpy(szJono, pszErotinmerkki + 1);
				sKenttanumero++;
				break;

			case 3:
				*pszErotinmerkki = (char) NULL;
				strcpy(lampotilaTietue->szKellonaika, szJono);
				strcpy(lampotilaTietue->szLampotila, pszErotinmerkki + 1);

				// Muutetaan desimaalipilkku desimaalipisteeksi
				pszDesimaalipilkku = strstr(lampotilaTietue->szLampotila, ",");
				*pszDesimaalipilkku = '.';

				// Tiputetaan rivin lopussa oleva rivinsiirto pois
				*(lampotilaTietue->szLampotila + strlen(lampotilaTietue->szLampotila) - 1) = (char) NULL;
				break;
		}
	}

	// Lisataan kentan erottimet
	strcpy(lampotilaTietue->szKentanerotin_1, LAMPOTILATIETO_KENTAN_EROTIN);
	strcpy(lampotilaTietue->szKentanerotin_2, LAMPOTILATIETO_KENTAN_EROTIN);
	strcpy(lampotilaTietue->szKentanerotin_3, LAMPOTILATIETO_KENTAN_EROTIN);
}


/***************************************************************************\
* FUNKTIO
*        haeLampotilaTiedot (char *pszTiedostonimi);
*
* INPUT
*        pszTiedostonimi -  Tiedoston nimi hakemistopolkuineen, josta 
*							tiedot haetaan.
*
* OUTPUT
*        Palauttaa :
*						0 - tietojen hakeminen onnistui
*						1 - tietojen hakeminen epaonnistui
*
* KUVAUS
*        Lukee kaikki lampotilatiedot tiedostosta ja tallentaa ne alkioina
*		 linkitettyyn listaan.
*
\***************************************************************************/
int haeLampotilaTiedot(char *pszTiedostonimi)
{
	LAMPOTILA_T lampotilaTietue, *tilanvaraus;
	FILE		*fpTiedosto;
	int			sPaluu = 1;
	char		szJono[ 
							 sizeof(lampotilaTietue.szIposoite)	+ 
							 sizeof(lampotilaTietue.szPaivamaara)	+ 
							 sizeof(lampotilaTietue.szKellonaika)	+ 
							 sizeof(lampotilaTietue.szLampotila)	+ 
						(3 * sizeof(lampotilaTietue.szKentanerotin_1)) ];

	
	// Avataan tiedosto luku moodissa
	if ((fpTiedosto = avaaTiedosto(pszTiedostonimi, AVAA_LUKU_MOODISSA)) != NULL)
	{
		// Vapautetaan linkitetyn listan alkioille varattu muisti
		tilanvaraus = ensimmainenLampotila;
		nykyinenLampotila = tilanvaraus;

		// Kaydaan linkitettya listaa lapi niin kauan kun siina on lampotila -alkioita
		while (tilanvaraus)
		{
			// Siirrytaan seuraavaan lampotila -alkioon
			tilanvaraus = tilanvaraus->seuraavaLampotila;

			// Vapautetaan edellisen alkion tilanvaraus
			free(nykyinenLampotila);

			// Otetaan alkion osoite talteen, jotta tila voidaan vapauttaa tuossa ylapuolella
			nykyinenLampotila = tilanvaraus;
		}

		// Nullataan linkitetyn listan pointterit
		ensimmainenLampotila = NULL;
		viimeinenLampotila = NULL;
		nykyinenLampotila = NULL;

		// Luetaan lampotilatieto rivi tiedostosta
		while (lueTiedostosta(fpTiedosto, szJono, sizeof(szJono) - 1) != NULL)
		{
			// Siirretaan rivin tiedot lampotilatietueeseen
			erotaLampotilakentat(szJono, &lampotilaTietue);

			// Lisataan lampotilatietue alkiona linkitettyyn listaan
			if (lisaaLampotilaListaan(&lampotilaTietue) == NULL)
				break;
		}

		// Suljetaan tiedosto
		suljeTiedosto(fpTiedosto);

		sPaluu = 0;
	}

	return sPaluu;
}


/***************************************************************************\
* FUNKTIO
*        haeEnsimmainenLampotila ();
*
* INPUT
*        Ei input parametreja
*
* OUTPUT
*        Linkitetyn listan ensimmainen lampotila -alkio. NULL, jos listassa
*		 ei ole alkioita.
*
* KUVAUS
*        Palauttaa ensimmaisen lampotila -alkion linkitetysta listasta.
*
\***************************************************************************/
LAMPOTILA_T *haeEnsimmainenLampotila()
{

	nykyinenLampotila = ensimmainenLampotila;
	return nykyinenLampotila;
}


/***************************************************************************\
* FUNKTIO
*        haeSeuraavaLampotila ();
*
* INPUT
*        Ei input parametreja
*
* OUTPUT
*        Linkitetyn listan seuraava lampotila -alkio. NULL, jos listassa
*		 ei ole enaa alkioita luettavana.
*
* KUVAUS
*        Palauttaa seuraavan lampotila -alkion linkitetysta listasta.
*
\***************************************************************************/
LAMPOTILA_T *haeSeuraavaLampotila()
{

	nykyinenLampotila = nykyinenLampotila->seuraavaLampotila;
	return nykyinenLampotila;
}