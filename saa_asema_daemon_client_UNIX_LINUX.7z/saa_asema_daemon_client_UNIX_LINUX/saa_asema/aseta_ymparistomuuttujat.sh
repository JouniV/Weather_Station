######################################################################################################################################
#
# - Talla skriptilla asetetaan saa-aseman ymparistomuuttujat
#
#       29.01.2009 Jouni Virtanen
#
#
######################################################################################################################################

DATA_TIEDOSTO_HAKEMISTO=$HOME/saa_asema/data_tiedostot
export DATA_TIEDOSTO_HAKEMISTO

LOKI_TIEDOSTO_HAKEMISTO=$HOME/saa_asema/loki_tiedostot
export LOKI_TIEDOSTO_HAKEMISTO

RABBIT_KORTIN_IP="192.168.0.104"
export RABBIT_KORTIN_IP

RABBIT_KORTIN_PORTTI="80"
export RABBIT_KORTIN_PORTTI

