######################################################################################################################################
#
# - Talla skriptilla kaynnistetaan saa-aseman daemon ohjelma
#
#       29.01.2009 Jouni Virtanen
#
#
######################################################################################################################################

# Asetetaan ymparistomuuttujat
. aseta_ymparistomuuttujat.sh

# Kaynnistetaan Daemon ohjelma tausta-ajoksi
nohup $HOME/saa_asema/daemon/exe/daemon &
