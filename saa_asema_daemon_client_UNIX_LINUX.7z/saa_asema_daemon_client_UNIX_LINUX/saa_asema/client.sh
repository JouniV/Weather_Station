######################################################################################################################################
#
# - Talla skriptilla kaynnistetaan saa-aseman client ohjelma
#
#       29.01.2009 Jouni Virtanen
#
#
######################################################################################################################################

# Asetetaan ymparistomuuttujat
. aseta_ymparistomuuttujat.sh

# Kaynnistetaan Client ohjelma
$HOME/saa_asema/client/exe/client
